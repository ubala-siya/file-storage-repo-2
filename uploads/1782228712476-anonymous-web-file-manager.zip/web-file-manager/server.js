const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});
const upload = multer({ storage: storage });

app.use(express.static('public'));
app.use(express.json());

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/api/files', (req, res) => {
    fs.readdir(uploadDir, (err, files) => {
        if (err) {
            return res.status(500).json({ error: 'Gagal membaca folder' });
        }
        const fileList = files.map(file => {
            try {
                const stats = fs.statSync(path.join(uploadDir, file));
                return {
                    name: file,
                    size: (stats.size / (1024 * 1024)).toFixed(2) + ' MB'
                };
            } catch (e) {
                return null;
            }
        }).filter(f => f !== null);
        res.json(fileList);
    });
});

app.post('/api/upload', upload.single('file-input'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('Tidak ada file yang diunggah.');
    }
    res.redirect('/');
});

app.get('/api/download/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(uploadDir, filename);
    if (fs.existsSync(filePath)) {
        res.download(filePath);
    } else {
        res.status(404).send('File tidak ditemukan');
    }
});

app.delete('/api/delete/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(uploadDir, filename);
    if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        res.json({ success: true, message: 'File berhasil dihapus' });
    } else {
        res.status(404).json({ success: false, message: 'File tidak ditemukan' });
    }
});

app.listen(PORT, () => {
    console.log(`Situs web berjalan di: http://localhost:${PORT}`);
});
