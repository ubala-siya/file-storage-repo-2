# Cloud File Manager

Source code siap pakai untuk website File Manager menggunakan Node.js (Express).

## Cara Menjalankan:
1. Pastikan sudah menginstal Node.js di komputer Anda.
2. Ekstrak file ZIP ini ke sebuah folder.
3. Buka Terminal / CMD di dalam folder tersebut.
4. Jalankan perintah: npm install
5. Jalankan perintah: npm start
6. Buka browser dan akses: http://localhost:3000
