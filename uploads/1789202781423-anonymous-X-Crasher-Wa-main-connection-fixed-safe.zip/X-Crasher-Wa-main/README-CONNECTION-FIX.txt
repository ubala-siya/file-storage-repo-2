# Correção de conexão

Esta versão altera somente a compatibilidade de dependências e adiciona um
helper separado para conexão segura.

Incluído:
- @dnuzi/baileys 0.0.7
- jimp 1.6.1
- useMultiFileAuthState para sessão persistente
- creds.update para salvar credenciais
- connection.update
- reconexão automática
- tratamento de logout

O `index.js` original foi preservado sem alterações.
O helper não implementa payloads de crash/disrupção nem execução arbitrária.
