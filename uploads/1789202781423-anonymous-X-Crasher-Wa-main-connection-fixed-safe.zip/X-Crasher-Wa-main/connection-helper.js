/*
 * Connection helper for X-Crasher-Wa-main
 * Scope: pairing, session persistence, connection.update and reconnect.
 * This file does not implement crash/disruption payloads or arbitrary code execution.
 */
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason
} = require('@dnuzi/baileys');

const path = require('path');

const SESSION_DIR = path.join(__dirname, 'auth_info_baileys');

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function startConnection() {
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);

  const sock = makeWASocket({
    auth: state,
    browser: ['Ubuntu', 'Chrome', '22.04.4'],
    printQRInTerminal: false,
    markOnlineOnConnect: false,
    syncFullHistory: false,
    fireInitQueries: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 60000,
    keepAliveIntervalMs: 25000,
    generateHighQualityLinkPreview: false
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    if (connection === 'open') {
      console.log('WhatsApp conectado com sucesso.');
      return;
    }

    if (connection !== 'close') return;

    const statusCode =
      lastDisconnect?.error?.output?.statusCode ??
      lastDisconnect?.error?.statusCode;

    if (statusCode === DisconnectReason.loggedOut) {
      console.log('Sessão encerrada. Faça o pareamento novamente.');
      return;
    }

    console.log(`Conexão encerrada${statusCode ? ` (status ${statusCode})` : ''}.`);
    console.log('Reconectando em 3 segundos...');

    await sleep(3000);
    startConnection().catch(err => {
      console.error('Erro ao reconectar:', err);
    });
  });

  return sock;
}

module.exports = { startConnection, SESSION_DIR };
