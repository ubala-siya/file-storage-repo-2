# Aviso de origem e atribuição

Este repositório é uma derivação autorizada do projeto [Nazuna Bot / DevTokyoVx/nazuna](https://github.com/DevTokyoVx/nazuna). O README do projeto de origem atribui a manutenção a Tokyo e menciona o criador original Hiudy.

A autorização para esta derivação foi comunicada pelo responsável pelo projeto ao mantenedor desta cópia. Mantém os créditos e a autorização associada quando modificares ou redistribuíres o código. O arquivo recebido não continha um `LICENSE` de raiz; o seu `package.json` identifica `ISC`, mas este aviso não substitui uma confirmação escrita dos termos nem concede direitos sobre dependências, marcas, personagens ou materiais de terceiros.

A imagem `dados/midias/menu.jpg` foi fornecida pelo utilizador desta derivação e não é apresentada como criação original dos autores do código.
