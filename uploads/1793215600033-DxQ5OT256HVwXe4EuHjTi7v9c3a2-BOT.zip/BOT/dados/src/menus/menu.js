const FRAME_TOP = '╭─ ͡┄┄───────ׅ─ׅ─ׅ──ׂ─ׅ──────⟡';
const FRAME_INNER_TOP = '┃ ┏☆∻∹⋰ ★∻∹⋰ ☆∻∹⋰ ★∻∹⋰┓';
const FRAME_INNER_BOTTOM = '┃ ┗☆∻∹⋰ ★∻∹⋰ ☆∻∹⋰ ★∻∹⋰┛';
const FRAME_BOTTOM = '╰─ ͡┄┄───────ׂ─ׅ───ׂ─ׅ─ׅ───ׅ───⟡';
const DIVIDER = '├╾═╼･ﾟ𖤐ﾟ･｡❄️｡･ﾟ𖤐ﾟ･╾═╼┤';
const LINE = '┃࣪ ╎—̳͟͞͞';

export default async function menu(
    prefix,
    botName = 'Bills Bot',
    userName = 'Usuário',
    {
        ownerName = 'Dono',
        isVip = false,
        userMention = '@usuário',
        currentTime = new Intl.DateTimeFormat('pt-AO', {
            timeZone: 'Africa/Angola',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hourCycle: 'h23'
        }).format(new Date())
    } = {}
) {
    const panel = `${FRAME_TOP}
${FRAME_INNER_TOP}
├╾═╼･ﾟ𖤐ﾟ･｡🧊｡･ﾟ𖤐ﾟ･╾═╼┤
├─ ⊹ 𖤐  *𝙿𝙰𝙸𝙽𝙴𝙻-𝙳𝙾-𝙱𝙸𝙻𝙻𝚂*
${DIVIDER}
${LINE} 🤖 *𝙱𝙾𝚃:* ${botName}
${LINE} 👑 *𝙲𝚁𝙸𝙰𝙳𝙾𝚁:* ${ownerName}
${LINE} 👤 *𝚄𝚂𝚄Á𝚁𝙸𝙾:* ${userMention}
${LINE} 💎 *𝚅𝙸𝙿:* ${isVip ? 'SIM ✅' : 'NÃO ❌'}
${LINE} ⏰ *𝙷𝙾𝚁𝙰:* ${currentTime}
${FRAME_INNER_BOTTOM}
${FRAME_BOTTOM}`;

    const mainMenu = `${FRAME_TOP}
${FRAME_INNER_TOP}
├╾═╼･ﾟ𖤐ﾟ･｡📚｡･ﾟ𖤐ﾟ･╾═╼┤
├─ ⊹ 𖤐  *𝙼𝙴𝙽𝚄 𝙿𝚁𝙸𝙽𝙲𝙸𝙿𝙰𝙻!*
├╾═╼･ﾟ𖤐ﾟ･｡📖｡･ﾟ𖤐ﾟ･╾═╼┤
${LINE} 🎧 *${prefix}menudown*
${LINE} 🎨 *${prefix}menulogos*
${LINE} ✨ *${prefix}menuedits*
${LINE} 🛡️ *${prefix}menuadm*
${LINE} 🎉 *${prefix}menubn*
${LINE} 👑 *${prefix}menudono*
${LINE} 👥 *${prefix}menumemb*
${LINE} 🧰 *${prefix}ferramentas*
${LINE} 🎭 *${prefix}menufig*
${LINE} 🎚️ *${prefix}alteradores*
${LINE} ⚔️ *${prefix}menurpg*
${LINE} 💎 *${prefix}menuvip*
${FRAME_INNER_BOTTOM}
${FRAME_BOTTOM}`;

    // userName fica disponível para compatibilidade com as chamadas existentes.
    void userName;
    return `${panel}\n\n${mainMenu}`;
}
