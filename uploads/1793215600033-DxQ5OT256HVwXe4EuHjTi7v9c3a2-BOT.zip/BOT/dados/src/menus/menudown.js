const FRAME_TOP = '╭─ ͡┄┄───────ׅ─ׅ─ׅ──ׂ─ׅ──────⟡';
const FRAME_INNER_TOP = '┃ ┏☆∻∹⋰ ★∻∹⋰ ☆∻∹⋰ ★∻∹⋰┓';
const FRAME_INNER_BOTTOM = '┃ ┗☆∻∹⋰ ★∻∹⋰ ☆∻∹⋰ ★∻∹⋰┛';
const FRAME_BOTTOM = '╰─ ͡┄┄───────ׂ─ׅ───ׂ─ׅ─ׅ───ׅ───⟡';
const LINE = '┃࣪ ╎—̳͟͞͞';

function renderSection(prefix, icon, dividerIcon, title, commands) {
    return `${FRAME_TOP}
${FRAME_INNER_TOP}
├╾═╼･ﾟ𖤐ﾟ･｡${icon}｡･ﾟ𖤐ﾟ･╾═╼┤
├─ ⊹ 𖤐  *${title}*
├╾═╼･ﾟ𖤐ﾟ･｡${dividerIcon}｡･ﾟ𖤐ﾟ･╾═╼┤
${commands.map(command => `${LINE} ${icon} *${prefix}${command}*`).join('\n')}
${FRAME_INNER_BOTTOM}
${FRAME_BOTTOM}`;
}

export default async function menudown(prefix = '#') {
    const sections = [
        renderSection(prefix, '🎵', '❄️', '𝙼Ú𝚂𝙸𝙲𝙰 & Á𝚄𝙳𝙸𝙾', [
            'letra', 'play', 'play2', 'spotify', 'soundcloud'
        ]),
        renderSection(prefix, '🎬', '🎞️', '𝚅Í𝙳𝙴𝙾𝚂 & 𝚂𝚃𝚁𝙴𝙰𝙼𝙸𝙽𝙶', [
            'playvid'
        ]),
        renderSection(prefix, '📥', '📦', '𝙳𝙾𝚆𝙽𝙻𝙾𝙰𝙳𝚂', [
            'tiktok', 'instagram', 'kwai', 'igstory', 'facebook', 'gdrive', 'mediafire', 'twitter'
        ]),
        renderSection(prefix, '📱', '🌐', '𝙼Í𝙳𝙸𝙰𝚂 𝚂𝙾𝙲𝙸𝙰𝙸𝚂', [
            'pinterest'
        ])
    ];

    return sections.join('\n\n');
}
