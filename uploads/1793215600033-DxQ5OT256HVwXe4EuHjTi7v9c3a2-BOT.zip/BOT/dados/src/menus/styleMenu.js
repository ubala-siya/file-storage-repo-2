const FRAME_TOP = '╭─ ͡┄┄───────ׅ─ׅ─ׅ──ׂ─ׅ──────⟡';
const FRAME_INNER_TOP = '┃ ┏☆∻∹⋰ ★∻∹⋰ ☆∻∹⋰ ★∻∹⋰┓';
const FRAME_INNER_BOTTOM = '┃ ┗☆∻∹⋰ ★∻∹⋰ ☆∻∹⋰ ★∻∹⋰┛';
const FRAME_BOTTOM = '╰─ ͡┄┄───────ׂ─ׅ───ׂ─ׅ─ׅ───ׅ───⟡';
const LINE = '┃࣪ ╎—̳͟͞͞';
const CATEGORY_ICONS = [
    '🎯', '🎨', '📡', '🛡️', '🎮', '👑', '👥', '🧰', '🎭', '🎚️', '⚔️',
    '💎', '🌟', '📚', '🧠', '🎲', '🌐', '⚡', '🔮', '🛠️', '🏆', '🪄',
    '🐉', '📦', '🎧', '💰', '🎤', '🦾', '🧩', '🚀', '🗺️', '🐾'
];
const LOWER_ICONS = [
    '❄️', '📖', '🧊', '🌙', '💠', '🔹', '✨', '🌱', '🦋', '🍀', '🌈',
    '🔆', '🎐', '🪷', '🌠', '🧿', '🪻', '☄️', '🌛', '🌜', '🪐', '☀️',
    '🫧', '🌿', '🪸', '🪺', '🪽', '💫', '🌌', '🌼', '🌀', '🎏'
];

function getDesign(args) {
    for (let index = args.length - 1; index >= 0; index -= 1) {
        const value = args[index];
        if (value && typeof value === 'object' && !Array.isArray(value)) {
            return value;
        }
    }
    return {};
}

function makeDivider(icon) {
    return `├╾═╼･ﾟ𖤐ﾟ･｡${icon}｡･ﾟ𖤐ﾟ･╾═╼┤`;
}

function stripSubheadingIcons(text, menuTitleIcon) {
    let result = text.trim();
    if (menuTitleIcon && result.startsWith(menuTitleIcon)) {
        result = result.slice(menuTitleIcon.length).trim();
    }
    if (menuTitleIcon && result.endsWith(menuTitleIcon)) {
        result = result.slice(0, -menuTitleIcon.length).trim();
    }
    return result;
}

/**
 * Reaplica a moldura do TXT ao texto produzido por um menu já existente.
 * O cabeçalho original é descartado; assim, nome do bot e nome do usuário
 * não aparecem. Os títulos, comandos e observações do menu são preservados.
 */
export function restyleMenuText(text, menuKey, args = []) {
    if (typeof text !== 'string' || !text.trim()) return text;

    const design = getDesign(args);
    const menuTopBorder = design.menuTopBorder ?? '╠═◆';
    const separatorIcon = design.separatorIcon ?? '◆';
    const bottomBorder = (design.bottomBorder ?? '╚════════════════════╝').trim();
    const middleBorder = design.middleBorder ?? '║ ';
    const menuItemIcon = design.menuItemIcon ?? '✦ ';
    const menuTitleIcon = design.menuTitleIcon ?? '🌌 ›';
    const sectionStart = `${menuTopBorder}${separatorIcon}`;
    const lines = text.split(/\r?\n/);
    const firstSection = lines.findIndex(line => line.startsWith(sectionStart) && line.includes('*'));

    // Mensagens simples de erro ou de lista vazia não têm cabeçalho antigo;
    // devolve-as sem inventar uma moldura vazia.
    if (firstSection < 0) return text.trim();

    const output = [];
    let upperIcon = CATEGORY_ICONS[0];
    let sectionIndex = 0;
    let isInsideSection = false;

    const closeSection = () => {
        output.push(FRAME_INNER_BOTTOM, FRAME_BOTTOM);
        isInsideSection = false;
    };

    for (let index = firstSection; index < lines.length; index += 1) {
        const line = lines[index];

        if (line.startsWith(sectionStart) && line.includes('*')) {
            if (isInsideSection) {
                closeSection();
                output.push('');
            }

            const title = line.slice(sectionStart.length).trim();
            upperIcon = CATEGORY_ICONS[sectionIndex % CATEGORY_ICONS.length];
            let lowerIcon = LOWER_ICONS[sectionIndex % LOWER_ICONS.length];

            output.push(
                FRAME_TOP,
                FRAME_INNER_TOP,
                makeDivider(upperIcon),
                `├─ ⊹ 𖤐  ${title}`,
                makeDivider(lowerIcon)
            );
            sectionIndex += 1;
            isInsideSection = true;
            continue;
        }

        if (line.trim() === bottomBorder) {
            if (isInsideSection) {
                closeSection();
                output.push('');
            }
            continue;
        }

        if (!isInsideSection) continue;
        if (!line.trim()) {
            // Evita uma linha vazia logo após a moldura; preserva espaços
            // internos usados para separar subseções do mesmo menu.
            if (output.length && output[output.length - 1] !== makeDivider(LOWER_ICONS[(sectionIndex - 1) % LOWER_ICONS.length])) {
                if (output[output.length - 1] !== '') output.push('');
            }
            continue;
        }

        if (line.startsWith(middleBorder)) {
            let content = line.slice(middleBorder.length).trimStart();

            if (!content.trim()) continue;

            if (menuTitleIcon && content.startsWith(menuTitleIcon)) {
                content = stripSubheadingIcons(content, menuTitleIcon);
                output.push(`${LINE} ✧ ${content}`);
                continue;
            }

            if (menuItemIcon && content.startsWith(menuItemIcon)) {
                content = content.slice(menuItemIcon.length).trim();
                if (content && !(content.startsWith('*') && content.endsWith('*'))) {
                    content = `*${content}*`;
                }
                output.push(`${LINE} ${upperIcon} ${content}`);
                continue;
            }

            output.push(`${LINE} ${content}`);
            continue;
        }

        output.push(`${LINE} ${line.trim()}`);
    }

    if (isInsideSection) closeSection();

    return output.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}
