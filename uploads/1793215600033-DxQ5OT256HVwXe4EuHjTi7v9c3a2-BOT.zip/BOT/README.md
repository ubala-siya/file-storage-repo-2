# Bills Bot

Bot de WhatsApp em Node.js, preparado para correr no **Termux** ou num ambiente Linux. Inclui comandos de utilidades, multimédia, jogos, administração e IA com **Google Gemini**.

> O código foi derivado de [DevTokyoVx/nazuna](https://github.com/DevTokyoVx/nazuna) com autorização comunicada pelo responsável pelo projeto. A origem e os créditos são mantidos em [NOTICE.md](NOTICE.md). Não uses este repositório para remover atribuições nem redistribuas fora das condições da autorização recebida.

## Requisitos

- Android com Termux atualizado (instalado de uma fonte mantida, como F-Droid ou GitHub)
- Node.js 20.9 ou superior e npm
- Git e FFmpeg
- Uma chave Gemini criada no [Google AI Studio](https://aistudio.google.com/app/apikey)
- Uma chave Vex **apenas para as funções que ainda dependem desse serviço** (downloads, logos/edições e transcrição). As funções não-Gemini permanecem dependentes dos fornecedores já configurados no código.

## Instalação no Termux

```bash
pkg update -y && pkg upgrade -y
pkg install -y git nodejs-lts ffmpeg python clang make pkg-config libvips
node --version
npm --version
export SHARP_FORCE_GLOBAL_LIBVIPS=1

git clone https://github.com/SEU_USUARIO/bills-bot.git
cd bills-bot
npm install
cp .env.example .env
nano .env
npm run config
npm start
```

Na primeira execução, segue o assistente para indicar o teu nome, número de WhatsApp e prefixo. O bot apresenta um QR de ligação; associa a sessão através de **WhatsApp → Dispositivos associados**. Nunca publiques a pasta de sessão/auth no GitHub.

### Configurar a chave Gemini

Abre `.env` e define a chave obtida no Google AI Studio:

```dotenv
GEMINI_API_KEY=COLOCA_A_TUA_CHAVE_AQUI
GEMINI_MODEL=gemini-3.8-flash
TENOR_API_KEY=
FF_LIKES_API_KEY=
```

O `.env` está no `.gitignore`; não partilhes nem comites a chave. O modelo pode ser alterado pela variável `GEMINI_MODEL`, se estiver disponível para a tua conta. A integração Gemini usa a API oficial `generateContent` do Google ([documentação](https://ai.google.dev/gemini-api/docs/text-generation)) e cobre os comandos de IA; não substitui as APIs de downloads, logos, edições ou transcrição. Os extras EmojiMix e likes de Free Fire também exigem, respetivamente, `TENOR_API_KEY` e `FF_LIKES_API_KEY` se os utilizares.

Para as outras funções de API, configura `site_vex` e `apikey_vex` no `dados/src/config.json`, se tiveres acesso a esse serviço. Se não utilizares essas funções, os comandos dependentes delas podem responder com erro de API.

### Manter o processo ativo

No Termux, o Sharp precisa de dependências nativas; o comando acima instala o compilador e o libvips do sistema antes do `npm install`. Se o pacote `libvips` não estiver disponível na tua instalação, ativa o repositório Termux apropriado e instala-o antes de prosseguir.

O Android pode suspender aplicações em segundo plano. Para uma sessão no Termux: 

```bash
pkg install -y tmux
termux-wake-lock
tmux new -s billsbot
npm start
```

Desanexa com `Ctrl+B` e depois `D`; para voltar: `tmux attach -t billsbot`. Para sair, usa `Ctrl+C` na sessão do bot e `termux-wake-unlock` quando terminares. Ajusta a otimização de bateria do Android para o Termux conforme necessário.

## Comandos de desenvolvimento

```bash
npm start          # arranque normal
npm run config     # configurar proprietário, prefixo e API Vex
npm run dev        # modo nodemon
npm run update     # atualizador do repositório indicado em config.json
```

Se a instalação do Sharp falhar no Termux, confirma que o Node é 20.9+ e que `pkg-config --modversion vips-cpp` apresenta uma versão; mantém `SHARP_FORCE_GLOBAL_LIBVIPS=1` definido durante a instalação.

Para publicar no teu GitHub, cria primeiro um repositório vazio e substitui `SEU_USUARIO` no clone/URL e na configuração do projeto. O comando `zipbot` usa `github_ofc` da configuração para descarregar o repositório. O atualizador também depende de `autor` e `repositorio`; confirma esses campos antes de o usar.

## Avisos

- O ZIP original não incluía um ficheiro `LICENSE` de raiz. O `package.json` upstream indica `ISC`, mas mantém a autorização explícita e confirma os termos de redistribuição antes de adicionar uma licença ao teu repositório.
- Não foram incluídos `node_modules`, sessões do WhatsApp nem chaves de API. As chaves que vinham expostas no código original foram removidas; gera e usa credenciais próprias nas variáveis de ambiente. Instala as dependências localmente com `npm install`.
- O WhatsApp pode limitar ou terminar sessões automatizadas; usa o bot de acordo com os termos aplicáveis e com consentimento dos participantes.
- Respeita as condições de cada API e os direitos de autor do conteúdo multimédia transferido.
