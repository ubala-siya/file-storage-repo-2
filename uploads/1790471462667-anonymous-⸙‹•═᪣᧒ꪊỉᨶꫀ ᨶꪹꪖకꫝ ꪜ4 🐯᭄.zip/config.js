const chalk = require("chalk")
const fs = require("fs")

global.ownerNumber = ["18492098766@s.whatsapp.net"]
global.nomerOwner = "18492098766"
global.nomorOwner = ['18492098766']
global.namaDeveloper = "𝐊𝐢𝐧𝐠-𝐉𝐮𝐢𝐜𝐞" //jangn diubh bng
global.namaOwner = "𝐊𝐢𝐧𝐠-𝐉𝐮𝐢𝐜𝐞"
global.namaBot = "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄"
global.versionBot = "4.0.0"
global.packname = "⸙‹•═᪣᧒ꪊỉᨶꫀ ᨶꪹꪖకꫝ ꪜ4 🐯᭄"
global.author = "𝐊𝐢𝐧𝐠-𝐉𝐮𝐢𝐜𝐞"
global.thumb = fs.readFileSync("./Andrazyy.jpg")
global.ThM = 'https://whatsapp.com/channel/0029Vb1ns4CKQuJCFJN1gJ3T'
global.isLink = 'https://whatsapp.com/channel/0029Vb1ns4CKQuJCFJN1gJ3T'

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})